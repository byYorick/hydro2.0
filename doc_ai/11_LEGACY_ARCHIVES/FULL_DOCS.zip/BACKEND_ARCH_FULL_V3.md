# BACKEND_ARCH_FULL_V3.md
# Полная архитектура Backend V3 (Детальный документ)

Этот документ описывает полную архитектуру backend-системы V3 для теплиц:  
контроллеры, зоны, рецепты, узлы, MQTT, Scheduler, Telemetry, Alerts с полной логикой.

---

# 1. Назначение Backend

Backend — **единственный мозг системы**. Он отвечает за:

- хранение структуры теплиц, зон, узлов, каналов;
- расчёт pH, EC, полива, климата, света;
- переходы фаз роста по рецептам;
- периодические циклы (Scheduler);
- монитринг и обработку телеметрии;
- генерацию команд устройствам;
- обработку статусов узлов (ONLINE/OFFLINE);
- API для фронта и внешних систем.

Никакая ESP-нода **не должна выполнять агрономические решения** — только backend.

---

# 2. Архитектурные слои

```
UI → API → Application Services → Domain → Controllers → Scheduler → NodeCoordinator → MQTT → ESP Nodes
```

---

# 3. Domain Layer (Основные модели)

## 3.1. Greenhouse
Теплица.

Поля:
- id
- name
- timezone
- type (GREENHOUSE, ROOM, FARM)
- coordinates
- description

Связи:
- hasMany Zones  
- hasMany Nodes

---

## 3.2. Zone
Зона — минимальная управляемая единица.

Поля:
- id
- greenhouse_id
- zone_type:  
  - PRODUCTION  
  - NUTRIENT_TANK  
  - CLIMATE  
  - LIGHT  
  - IRRIGATION  
  - TECH
- crop_id
- active_recipe_id
- current_phase_id
- state: SETUP / RUNNING / PAUSED / ALARM / FINISHED
- runtime_config (JSON — цели фазы)

Связи:
- hasMany DeviceNode  
- hasMany ZoneCycleInstance  

---

## 3.3. DeviceNode
ESP-устройство.

Поля:
- id
- zone_id
- node_type (PH_BOX, EC_BOX, CLIMATE_BOX, etc)
- fw_version
- status: ONLINE / OFFLINE / DEGRADED
- last_seen
- ip_last_seen
- meta (JSON)

---

## 3.4. DeviceChannel
Канал узла.

Поля:
- channel_name
- channel_type: SENSOR / ACTUATOR
- metric_type (PH, EC, TEMP_AIR, HUMIDITY…)
- actuator_type (PUMP, VALVE, FAN, HEATER, LIGHT…)
- safe_limits:
  - max_duration_ms
  - min_off_time_ms
  - duty_cycle
- calibration_data

---

## 3.5. Recipe (Preset)
Рецепт выращивания.

Поля:
- id
- crop_id
- name
- description
- version

---

## 3.6. GrowthPhase
Фаза роста.

Поля:
- recipe_id
- order
- name
- duration_days
- ranges:
  - ph_min / ph_max
  - ec_min / ec_max
  - temp_air_min / temp_air_max
  - humidity_min / humidity_max
  - light_hours
  - light_intensity

---

## 3.7. CycleDefinition
Описание цикла.

Поля:
- subsystem: PH, EC, CLIMATE, IRRIGATION, LIGHT
- strategy: PERIODIC / EVENT / HYBRID
- interval_sec
- triggers (JSON)

---

## 3.8. ZoneCycleInstance
Активный цикл.

Поля:
- zone_id
- next_run_at
- last_run_at
- last_result
- enabled

---

## 3.9. TelemetrySample
Телеметрия.

Поля:
- zone_id
- node_id
- channel_name
- metric_type
- value
- timestamp

---

## 3.10. Command
Команда для ноды.

Поля:
- id
- node_id
- channel_name
- command_type
- payload
- status: PENDING / SENT / ACK / TIMEOUT / FAILED

---

## 3.11. ZoneEvent / Alert
События и аварии.

---

# 4. Application Services

## ZoneService
- создание зон;  
- применение рецептов;  
- смена фаз;  
- перевод в RUNNING/PAUSED/ALARM.

## RecipeService
- CRUD рецептов;  
- проверка фаз;  
- кэш рецептов для runtime.

## DeviceNodeService
- регистрация ноды;  
- генерация NodeConfig;  
- обновление статусов.

## TelemetryService
- приём telemetry;  
- валидация;  
- сохранение;  
- нормализация;  
- создание алертов при выходе за диапазон.

## CommandService
- создание команд;  
- обновление статуса;  
- история.

## AlertService
- генерация аварий;  
- очистка;  
- отправка уведомлений.

---

# 5. Контроллеры подсистем (Zone Controllers)

## 5.1. ZoneNutrientController (pH / EC)
- получает последние pH/EC;  
- сравнивает с диапазонами фазы;  
- рассчитывает дозировку;  
- создаёт команды насосам;  
- пишет события.

## 5.2. ZoneClimateController
- t° / RH / fans / heater;  
- гистерезисы;  
- поддержание диапазонов.

## 5.3. ZoneIrrigationController
- интервалы полива;  
- дозы;  
- управление клапанами;  
- при необходимости учитывает уровень воды.

## 5.4. ZoneLightingController
- часы света;  
- интенсивность;  
- управление реле или PWM.

---

# 6. Scheduler — ядро исполнения

Каждую минуту:

```
cycles = ZoneCycleInstance where next_run_at <= now

for each cycle:
    controller = matchSubsystem(cycle.subsystem)
    result = controller.run(zone)
    save Commands
    log Events
    cycle.last_run_at = now
    cycle.next_run_at = now + interval
```

Scheduler не принимает решений — он запускатор.

---

# 7. MQTT Layer

## 7.1. Входящий трафик от узлов

### telemetry
Топик:
```
hydro/{gh}/{zone}/{node}/{channel}/telemetry
```

Payload:
```json
{
  "node_id": "nd-ph-1",
  "channel": "ph_sensor",
  "metric_type": "PH",
  "value": 5.82,
  "timestamp": 1680001234
}
```

### status (LWT)
ONLINE / OFFLINE

### config_response

### command_response

---

## 7.2. Исходящий трафик

### commands
```
hydro/{gh}/{zone}/{node}/{channel}/command
```

Payload:
```json
{
  "action": "run_pump",
  "duration_ms": 2000
}
```

### config
```
hydro/{gh}/{zone}/{node}/config
```

---

## 7.3. MQTT Listener → Router → Handlers

- Listener подписывается на все группы топиков.  
- Router разбирает topic → вызывает TelemetryHandler / StatusHandler и т.п.

---

# 8. NodeCoordinator

Назначение:
- сериализовать команды в JSON;
- определить MQTT-топик;
- публиковать;  
- отслеживать ACK/TIMEOUT.

Пример:

```
sendCommand(Command):
    topic = buildTopic(...)
    payload = serialize(...)
    mqtt.publish(topic, payload, qos=1)
```

---

# 9. Общение с фронтом

Front получает два вида данных:

### 1. REST API  
- CRUD
- состояния зон
- списки телеметрии
- списки нод
- последние значения

### 2. WebSocket  
- новые telemetry
- alerts
- status изменений узлов
- обновления зон

---

# 10. Состояния зоны (State Machine)

```
SETUP → RUNNING → PAUSED → RUNNING
               ↘
                ALARM → SETUP/RUNNING
```

---

# 11. Роль ИИ

ИИ имеет право:

- подбирать рецепты;  
- менять параметры фаз;  
- оптимизировать стратегии контроллеров;  
- создавать новые CycleDefinition.

ИИ не имеет права:

- менять MQTT-механизмы;  
- менять доменную структуру;  
- переносить бизнес-логику в ноды.

---

# 12. План внедрения Backend V3

1. Создать модели доменной области V3.  
2. Создать Application Services.  
3. Внедрить MQTT слой (Listener + Router + Handlers).  
4. Реализовать NodeCoordinator.  
5. Реализовать Scheduler.  
6. Добавить контроллер pH/EC.  
7. Добавить UI зоны.  
8. Добавлять климат, полив, свет.  

---

# Конец файла
