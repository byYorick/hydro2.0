# RECIPE_ENGINE_FULL_V3.md
# Полная архитектура Recipe Engine V3 (Рецепты, фазы, цели, зависимости, переходы)

Документ описывает полный движок рецептов V3:
структуру данных, работу фаз, применённые цели pH/EC/климата,
автоматические переходы, ручные действия и интеграцию с зонами.

---

# 1. Назначение Recipe Engine

Recipe Engine отвечает за:

- определение целей зоны (targets),
- определение фаз роста,
- параметры pH / EC / климата / освещения,
- длительность фаз,
- автоматические переходы,
- вычисление целей на основе истории,
- снабжение Backend контроллеров актуальными значениями.

---

# 2. Модель рецепта

```
Recipe
  recipe_id
  name
  phases[] → RecipePhase
```

## RecipePhase

```json
{
  "phase_id": "veg-1",
  "name": "VEG",
  "duration_hours": 48,
  "targets": {
    "ph": 5.8,
    "ec": 1.6,
    "temp_air": 23,
    "humidity": 55,
    "light_hours": 18
  }
}
```

---

# 3. Применение рецепта зоне

Через API:

POST /api/zones/{id}/apply_recipe

Backend создаёт:

```
ZoneRecipeInstance
  - zone_id
  - recipe_id
  - current_phase
  - start_ts
  - phase_start_ts
```

---

# 4. Логика фаз

Фаза содержит:

- цели (pH, EC, t°, RH)
- длительность
- поведение

Переходы:

1. **Автоматический** (по времени)
2. **Ручной** (через UI)
3. **По рекомендациям AI**

---

# 5. Алгоритм обновления фаз

Фоновый Scheduler каждые 1 мин:

```
if now - phase_start_ts >= duration_hours:
    next_phase
```

Если фаза последняя → остаёмся в ней.

---

# 6. Генерация целей для зоны

Backend вычисляет:

```
zone.targets = recipe.phases[current_phase].targets
```

Эти цели используются:

- ZoneNutrientController (pH/EC)
- ZoneClimateController (Temp/RH)
- ZoneLightController (свет)
- ZoneIrrigationController (поливы)

---

# 7. Интеграция с NodeConfig

При смене фазы:

1. Backend обновляет цели зоны
2. Backend генерирует новый NodeConfig
3. Отправляет config → узлам
4. Узлы обновляют частоты опроса и каналы

---

# 8. Тонкие настройки рецептов

### 8.1. Этажность EC
Можно описывать не одно EC значение, а кривую:

```
ec:
  base: 1.4
  ramp_per_day: 0.15
```

### 8.2. Динамический свет
```
light:
  hours: 18
  intensity_curve: [...]
```

### 8.3. Климат
Можно задать диапазоны:
```
temp_air: { min: 22, max: 26 }
humidity: { min: 50, max: 60 }
```

---

# 9. История фаз

Хранится:

- начало каждой фазы,
- длительность,
- события,
- действия оператора,
- коррекции AI.

---

# 10. Интеграция с AI

AI может:

- рекомендовать EC,
- рекомендовать pH,
- рекомендовать длительность фазы,
- предложить переход фазы,
- объяснить поведение рецепта.

---

# 11. API Recipe Engine

## GET /api/recipes
## GET /api/recipes/{id}
## POST /api/recipes
## PUT /api/recipes/{id}
## POST /api/zones/{id}/apply_recipe
## POST /api/zones/{id}/next_phase
## POST /api/zones/{id}/set_phase

---

# 12. Пример полного рецепта

```json
{
  "recipe_id": "green-leaf-veg",
  "name": "Leafy Greens Vegetative Cycle",
  "phases": [
    {
      "phase_id": "seedling",
      "name": "Seedling",
      "duration_hours": 72,
      "targets": {
        "ph": 6.0,
        "ec": 0.9,
        "temp_air": 24,
        "humidity": 70,
        "light_hours": 16
      }
    },
    {
      "phase_id": "veg",
      "name": "Vegetative",
      "duration_hours": 120,
      "targets": {
        "ph": 5.8,
        "ec": 1.6,
        "temp_air": 23,
        "humidity": 55,
        "light_hours": 18
      }
    }
  ]
}
```

---

# 13. Будущее развитие

- авто‑адаптация фаз на основе telemetry (ML)
- прогноз дозировок
- поддержка мульти‑кривых (климат, свет)
- импорт рецептов (cloud library)

---

# Конец файла RECIPE_ENGINE_FULL_V3.md
