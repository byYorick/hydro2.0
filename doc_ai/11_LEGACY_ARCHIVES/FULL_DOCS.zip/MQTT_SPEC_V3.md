# MQTT Спецификация V3

Топики:
- hydro/{gh}/{zone}/{node}/{channel}/telemetry
- ...
Типы сообщений:
- telemetry
- command
- event
- config
...