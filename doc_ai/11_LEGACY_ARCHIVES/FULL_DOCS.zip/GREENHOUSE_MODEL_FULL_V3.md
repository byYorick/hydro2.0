# GREENHOUSE_MODEL_FULL_V3.md
# Полная архитектура модели теплицы V3
# (Greenhouses, Zones, Nodes, Channels, Devices, State, Events)

Документ описывает **полную доменную модель теплицы** в системе V3:
структуру сущностей, связи, состояние, жизненные циклы, события,
и то, как Backend хранит и рассчитывает всю логику тепличного хозяйства.

---

# 1. Общая концепция модели теплицы

В основе архитектуры — строгая, модульная, расширяемая модель:

```
Greenhouse → Zones → Devices (Nodes) → Channels
```

Backend полностью контролирует:

- состояние зон
- рецепты и фазы
- цели pH/EC/климата
- связи между нодами
- историю событий
- расписания
- все контроллеры

---

# 2. Структура модели

## 2.1. Greenhouse

```
Greenhouse {
  gh_id
  name
  location
  zones[]
}
```

Может быть 1 или много теплиц в системе.

---

## 2.2. Zone

Зона — основной объект управления.

```
Zone {
  zone_id
  gh_id
  name
  status   (RUNNING / PAUSED / ALARM / WARNING)
  recipe_instance_id
  devices[]
  controllers_state
  targets {
      ph
      ec
      temp_air
      humidity
      light_hours
  }
  metrics {last telemetry}
}
```

Зона объединяет узлы и контроллеры.

---

## 2.3. DeviceNode (узел ESP32)

```
DeviceNode {
  node_id
  zone_id
  type        (PH / EC / CLIMATE / IRRIG / LIGHT)
  status      (ONLINE / OFFLINE)
  wifi_rssi
  hw_version
  fw_version
  config
  channels[]
}
```

---

## 2.4. DeviceChannel

Каждый канал — сенсор или исполнитель.

```
DeviceChannel {
  channel_id
  node_id
  name
  type           (SENSOR / ACTUATOR)
  metric         (PH / EC / TEMP / RH / FLOW…)
  actuator_type  (PUMP / VALVE / FAN / RELAY / PWM)
}
```

---

## 2.5. RecipeInstance (применённый рецепт зоны)

```
ZoneRecipeInstance {
  instance_id
  zone_id
  recipe_id
  current_phase
  phase_start_ts
  start_ts
}
```

---

## 2.6. TelemetrySample

Хранится в TSDB (Influx, Timescale).

```
TelemetrySample {
  zone_id
  node_id
  channel
  metric_type
  value
  ts
}
```

---

## 2.7. Command

```
Command {
  cmd_id
  zone_id
  node_id
  channel
  cmd
  params
  status (QUEUED / SENT / ACK / ERROR / TIMEOUT)
  created_ts
}
```

---

## 2.8. Events

```
ZoneEvent {
  event_id
  zone_id
  type
  details
  ts
}
```

Типы событий:

- PH_CORRECTED
- EC_CORRECTED
- IRRIGATION_STARTED
- IRRIGATION_FINISHED
- TEMP_HIGH
- TEMP_LOW
- FLOW_LOW
- LEVEL_LOW
- NODE_OFFLINE
- ALARM_ENTER
- ALARM_EXIT

---

## 2.9. Alerts

```
Alert {
  alert_id
  zone_id
  type
  details
  status   (ACTIVE / RESOLVED)
  ts
}
```

---

# 3. Связи между сущностями

```
Greenhouse 1—N Zones
Zone 1—N DeviceNodes
DeviceNode 1—N DeviceChannels
Zone 1—1 RecipeInstance
Zone 1—N TelemetrySamples
Zone 1—N Events
Zone 1—N Alerts
```

---

# 4. Состояние зон (Zone State Model)

## 4.1. Основные статусы зоны

- **RUNNING** — контроллеры активны.
- **PAUSED** — контроллеры остановлены.
- **WARNING** — частичная проблема.
- **ALARM** — критическая проблема.

## 4.2. Правила ALARM

ALARM наступает, если:

- критическая нода offline
- pH или EC за пределами более 10 минут
- t° или RH критично высокие/низкие
- нет потока (NO_FLOW)
- уровень ниже min_level
- backend видит серию ошибок команд

---

# 5. Автоматический переход фаз

```
if now - phase_start_ts >= phase.duration:
    next_phase()
```

Backend обновляет:

- фаза
- цели
- NodeConfig
- контроллеры

---

# 6. Логика привязки узлов к зонам

Узел может быть:

- **жёстко привязан** к зоне,
- **автоматически назначен** при добавлении,
- **перенесён** в другую зону.

Backend хранит:

- node.zone_id
- node.channels
- node metrics

---

# 7. Логика хранения параметров зоны

Backend хранит:

```
zone.metrics = {
  ph,
  ec,
  temp_air,
  humidity,
  flow,
  level
}
```

Обновляется:

- через telemetry flow,
- через WebSocket пуши на фронт.

---

# 8. Внешние API зоны

### GET /api/zones  
### GET /api/zones/{id}  
### POST /api/zones/{id}/pause  
### POST /api/zones/{id}/resume  
### POST /api/zones/{id}/next_phase  
### POST /api/zones/{id}/set_phase  

Зона — главный управляемый объект UI.

---

# 9. Контроллеры зоны (integration overview)

Контроллеры используют:

- zone.targets
- zone.metrics
- recipe_instance
- devices
- schedules

Результат:  
**команды к узлам ESP32 через MQTT**.

---

# 10. Роль Backend в актуализации модели

Backend:

- принимает telemetry,
- обновляет zone.metrics,
- записывает history,
- запускает контроллеры,
- формирует команды,
- следит за zone.status,
- обновляет targets при смене фазы,
- создаёт events и alerts.

---

# 11. Диаграмма полной доменной модели V3

```
Greenhouse
   │
   └── Zone
         │
         ├── RecipeInstance
         │       └── phases
         │
         ├── Devices (ESP32 Nodes)
         │       └── Channels
         │
         ├── TelemetrySamples (TSDB)
         │
         ├── Commands
         │
         ├── Events
         │
         └── Alerts
```

---

# 12. Будущее развитие модели

- Мульти‑тепличный режим (несколько хозяйств)
- Поддержка под‑зон
- “Virtual devices” (агрегаты сенсоров)
- Модели энергопотребления
- Интеграция камер (vison AI)
- Отдельная модель “Water System”

---

# Конец файла GREENHOUSE_MODEL_FULL_V3.md
