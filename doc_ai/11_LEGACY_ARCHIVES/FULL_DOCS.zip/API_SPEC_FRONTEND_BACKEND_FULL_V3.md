# API_SPEC_FRONTEND_BACKEND_FULL_V3.md
# Полная детальная спецификация API между Frontend и Backend (V3)

Документ описывает все REST и WebSocket API,
которые используются современным UI/UX фронтендом для управления теплицей.

---

# 1. Общие принципы API

Frontend общается только с Backend, **никогда — напрямую с MQTT или узлами**.

API выполняет:

- управление теплицами и зонами,
- изменение рецептов и фаз,
- запуск команд (manual actions),
- отображение телеметрии и истории,
- работу с событиями и alert’ами,
- мониторинг устройств,
- управление конфигурациями узлов.

Backend всегда:

- валидирует вход,
- логирует действия,
- синхронизирует команды с MQTT,
- гарантирует целостность состояния.

---

# 2. Архитектура API

API разделено на модули:

```
/api
  /greenhouses
  /zones
  /recipes
  /devices
  /commands
  /events
  /alerts
  /telemetry
  /history
  /system
  /ai
```

Frontend подключается через:

- **REST** — CRUD, действия пользователя
- **WebSocket** — realtime обновления

---

# 3. Auth (пока не используется)
V3 в DEV не требует авторизации.

---

# 4. API: Greenhouses

## 4.1. GET /api/greenhouses
Ответ:
```json
[
  {
    "gh_id": "gh-1",
    "name": "Main Greenhouse",
    "zones": 14
  }
]
```

## 4.2. GET /api/greenhouses/{id}
Возвращает список зон + метаданные.

---

# 5. API: Zones

## 5.1. GET /api/zones
Список всех зон.

```json
[
  {
    "zone_id": "zn-3",
    "name": "Zone 3",
    "status": "RUNNING",
    "target_ph": 5.8,
    "target_ec": 1.6,
    "current_phase": "VEG",
    "alerts": 0
  }
]
```

## 5.2. GET /api/zones/{id}
Полная информация:

- текущие параметры
- рецепт
- активная фаза
- устройства
- события

## 5.3. POST /api/zones/{id}/action
Действия:

- `pause`
- `resume`
- `next_phase`
- `irrigate_now`
- `drain_now`

Payload:
```json
{ "action": "irrigate_now" }
```

---

# 6. API: Recipes

## 6.1. GET /api/recipes
Список рецептов.

## 6.2. GET /api/recipes/{id}
Подробные фазы.

## 6.3. POST /api/recipes
Создание нового рецепта.

## 6.4. PUT /api/recipes/{id}
Обновление рецепта.

## 6.5. POST /api/zones/{id}/apply_recipe
Применение рецепта к зоне.

Payload:
```json
{ "recipe_id": "rc-veg-01" }
```

---

# 7. API: Devices (узлы)

## 7.1. GET /api/devices
Список узлов:

```json
[
  {
    "node_id": "nd-ph-1",
    "type": "PH",
    "status": "ONLINE",
    "rssi": -56,
    "channels": 3
  }
]
```

## 7.2. GET /api/devices/{node_id}
Возвращает:

- статус
- конфигурацию
- привязку к зоне
- telemetry last values
- историю команд узла

## 7.3. POST /api/devices/{node_id}/action
Manual действия:

```json
{
  "channel": "pump_acid",
  "cmd": "run_pump",
  "duration_ms": 2000
}
```

---

# 8. API: Commands

## 8.1. POST /api/commands
Создаёт команду для узла:

```json
{
  "zone_id": "zn-3",
  "node_id": "nd-ec-1",
  "channel": "pump_nutrient",
  "cmd": "run_pump",
  "duration_ms": 3000
}
```

Ответ:
```json
{
  "cmd_id": "cmd-22311",
  "status": "QUEUED"
}
```

## 8.2. GET /api/commands/{id}
Статус команды:

- QUEUED
- SENT
- ACK
- ERROR
- TIMEOUT

---

# 9. API: Alerts

## 9.1. GET /api/alerts
Список всех активных alert’ов.

## 9.2. POST /api/alerts/{id}/resolve
Закрытие alert’а.

---

# 10. API: Events

## 10.1. GET /api/events?zone_id=zn-3
История событий зоны.

---

# 11. API: Telemetry

## 11.1. GET /api/telemetry/latest
Последние значения:

```json
{
  "ph": 5.82,
  "ec": 1.61,
  "temp_air": 24.1,
  "humidity": 54
}
```

---

# 12. API: History (графики)

## 12.1. GET /api/history/ph?zone=zn-3&from=...&to=...

Возвращает массив точек.

---

# 13. API: System

## 13.1. GET /api/system/status
Состояние backend:

```json
{
  "uptime": 120300,
  "nodes_online": 12,
  "zones": 8,
  "alerts": 3
}
```

---

# 14. API: AI

## 14.1. POST /api/ai/recommend
```json
{
  "zone_id": "zn-3",
  "context": "ph_high"
}
```

Ответ:
```json
{
  "suggestion": "Уменьшить дозу основания на 10%",
  "reason": "PH держится выше нормы несколько часов"
}
```

---

# 15. WebSocket API

Адрес:
```
ws://server/ws
```

Типы сообщений:

```
TELEMETRY_UPDATE
ALERT
EVENT
ZONE_UPDATE
COMMAND_STATUS
NODE_STATUS
```

Пример:
```json
{
  "type": "TELEMETRY_UPDATE",
  "zone_id": "zn-3",
  "node_id": "nd-ph-1",
  "metric": "PH",
  "value": 5.82,
  "ts": 1710012300
}
```

---

# 16. Ошибки API

Формат:
```json
{
  "error": "zone_not_found",
  "details": "Zone zn-29 does not exist"
}
```

Типы:

- zone_not_found  
- node_not_found  
- invalid_action  
- invalid_recipe  
- command_rejected  
- backend_timeout  

---

# 17. Версионирование API

Версия API:
```
X-API-Version: 3
```

Backend оставляет backwards compatibility.

---

# Конец файла API_SPEC_FRONTEND_BACKEND_FULL_V3.md
