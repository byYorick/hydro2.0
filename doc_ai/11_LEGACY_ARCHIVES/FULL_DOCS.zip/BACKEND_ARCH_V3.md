# Backend Архитектура V3

Этот документ описывает **архитектуру backend-части системы V3** для управления теплицами, зонами и узлами (ESP32) через MQTT.

Он опирается на документ `LOGIC_ARCH_V3.md` и детализирует:
- слои backend-приложения,
- основные сервисы и их ответственность,
- работу с MQTT,
- планировщик (Scheduler),
- координацию узлов (NodeCoordinator),
- API для фронта и интеграций.

---

## 1. Общий обзор backend V3

Backend — это **единственный “мозг” системы**.  
Он отвечает за:

- хранение доменных данных (теплицы, зоны, культуры, рецепты, фазы, устройства),
- принятие решений (pH/EC/полив/климат/свет),
- планирование действий (циклы),
- формирование команд для узлов,
- приём и обработку телеметрии,
- генерацию событий/алертов,
- предоставление API для UI и внешних интеграций.

Архитектурно backend делится на следующие слои:

```text
┌───────────────────────────────┐
│          UI / Clients         │ (Web, mobile, external)
└────────────┬──────────────────┘
             │ HTTP / WebSocket
┌────────────▼──────────────────┐
│           API Layer           │
└────────────┬──────────────────┘
             │ (DTO/Services)
┌────────────▼──────────────────┐
│      Application Services     │
└────────────┬──────────────────┘
             │ (доменные модели)
┌────────────▼──────────────────┐
│         Domain Layer          │
└────────────┬──────────────────┘
             │ (бизнес-логика зон)
┌────────────▼──────────────────┐
│ Controllers & Scheduler Layer │
└────────────┬──────────────────┘
             │ (команды и MQTT)
┌────────────▼──────────────────┐
│      NodeCoordinator/MQTT     │
└───────────────────────────────┘
```

---

## 2. Слои backend

### 2.1. API Layer

**Назначение:**  
Предоставляет интерфейс для:

- фронтенда (панель управления),
- мобильных приложений,
- внешних сервисов/интеграций.

**Интерфейсы:**

1. **REST API**
   - CRUD-операции:
     - `/greenhouses`
     - `/zones`
     - `/nodes`
     - `/channels`
     - `/recipes`
     - `/crops`
   - действия:
     - `/zones/{id}/actions/pause`
     - `/zones/{id}/actions/resume`
     - `/zones/{id}/actions/apply_recipe`
     - `/zones/{id}/actions/change_phase`
     - `/zones/{id}/actions/manual_irrigation`
     - `/nodes/{id}/actions/test_channel`

2. **WebSocket / SSE**
   - push-события:
     - обновления телеметрии,
     - изменения состояний зон,
     - новые алерты,
     - изменения статусов нод.

**Особенности:**

- API Layer не содержит бизнес-логики.
- Вся логика — в Application Services или Controllers Layer.
- Валидация входящих данных осуществляется через DTO/формы.

---

### 2.2. Application Services

Application Services — это “сценарные” сервисы, которые:

- инкапсулируют операции над несколькими моделями,
- координируют доменные операции,
- используются API слоем, контроллерами, планировщиком.

Примеры:

1. **GreenhouseService**
   - создать/обновить теплицу,
   - получить список зон теплицы,
   - общие агрегированные данные (статистика по теплице).

2. **ZoneService**
   - создать/обновить зону,
   - применить рецепт к зоне,
   - сменить фазу роста,
   - перевести зону в RUNNING/PAUSED/ALARM/SETUP,
   - получить агрегированное состояние зоны (для UI).

3. **RecipeService**
   - создание/редактирование рецептов,
   - управление фазами роста,
   - создание копий рецептов.

4. **DeviceNodeService**
   - регистрация нод,
   - обновление статуса нод,
   - описание каналов нод (сенсоры/актуаторы),
   - генерация NodeConfig из доменных сущностей.

5. **TelemetryService**
   - приём телеметрии (из MQTT-обработчиков),
   - нормализация, валидация, преобразование,
   - запись `TelemetrySample`,
   - кэширование последних значений (например, Redis),
   - дергание AlertService при выходе за пределы.

6. **AlertService**
   - создание алертов и событий,
   - лог событий по зонам и нодам,
   - возможная интеграция с внешними уведомлениями (Telegram/email).

7. **CommandService**
   - создание новых команд для нод,
   - обновление статусов команд,
   - история команд.

Application Services **знают про Domain Layer**, но не про MQTT/узлы напрямую — вместо этого они вызывают NodeCoordinator или ради контроллеров.

---

### 2.3. Domain Layer

Включает:

- модели:
  - Greenhouse, Zone, DeviceNode, DeviceChannel,
  - Crop, Recipe, GrowthPhase,
  - CycleDefinition, ZoneCycleInstance,
  - TelemetrySample, Command, ZoneEvent, Alert;
- связи между ними;
- доменные инварианты.

Примеры инвариантов:

- Зона `zone_type = NUTRIENT_TANK` не может иметь `crop_id`.
- Рецепт должен иметь хотя бы одну фазу роста.
- Фаза роста должна принадлежать рецепту.
- Нода должна принадлежать либо теплице, либо зоне (в зависимости от твоей модели).
- DeviceChannel с `channel_type=SENSOR` не может иметь actuator_type.

Domain Layer — **ядро данных и ограничений**.

---

### 2.4. Controllers & Scheduler Layer

Это слой “живой логики” управления.

Состоит из:

1. **Zone Controllers**
   - `ZoneClimateController`
   - `ZoneNutrientController`
   - `ZoneIrrigationController`
   - `ZoneLightingController`

2. **Scheduler (Планировщик)**

#### 2.4.1. Zone Controllers

Каждый контроллер:

- принимает:
  - `Zone`,
  - активные `Recipe`/`GrowthPhase`,
  - последние `TelemetrySample`,
  - статусы нод,
  - `ZoneCycleInstance` (если нужно),
  - текущие события/алармы,
- возвращает:
  - новый список `Command` для нод,
  - возможные обновления `Zone` (например, смена фазы),
  - новые `ZoneEvent` и `Alert`.

Пример (упрощённый) работы `ZoneNutrientController`:

1. Берём бак-зону `Zone` типа `NUTRIENT_TANK`.
2. Читаем текущий pH и EC (последние TelemetrySample по баку).
3. Сравниваем с целевыми диапазонами текущей фазы (`GrowthPhase`).
4. Если pH ниже диапазона → создаём `Command` на `pump_base` на X сек исходя из модели системы.
5. Если EC ниже — команда на питательный насос.
6. Записываем событие “коррекция pH/EC”.
7. Возвращаем данные в Scheduler/CommandService для дальнейшей обработки.

Контроллеры **ничего не знают о MQTT**, только о доменных объектах и командах.

---

#### 2.4.2. Scheduler (Планировщик)

Scheduler отвечает за:

- плановый запуск контроллеров,
- привязку к `ZoneCycleInstance`.

Типичный цикл работы Scheduler:

1. По таймеру (например, каждую минуту) Scheduler выполняет:

   ```pseudo
   cycles = find all ZoneCycleInstance
            where enabled = true
              and next_run_at <= now

   for each cycle in cycles:
       controller = pickController(cycle.subsystem)
       result = controller.run(zone, cycle)
       save commands from result
       save zone updates (if any)
       save events/alerts
       update cycle.last_run_at = now
       cycle.next_run_at = now + interval
   ```

2. Для разных `subsystem`:
   - PH/EC → `ZoneNutrientController`,
   - CLIMATE → `ZoneClimateController`,
   - IRRIGATION → `ZoneIrrigationController`,
   - LIGHTING → `ZoneLightingController`.

Таким образом Scheduler **не делает бизнес-логики сам**, а только “расписание”.

---

### 2.5. NodeCoordinator & MQTT Layer

Этот слой — мост между backend и реальными нодами.

Состоит из:

- `MqttClientInterface` + реализация (`PhpMqttClient`),
- `MqttListener` (запуск слушателя),
- `MqttRouter` (topic → handler),
- MQTT-хендлеры (telemetry/status/config_response/command_response),
- `NodeCoordinator` (исходящие команды и конфиги).

#### 2.5.1. NodeCoordinator

Основные задачи:

- принимать `Command` и `NodeConfig` из Application Services/Controllers,
- сериализовать их в JSON,
- определить корректный MQTT topic для ноды и канала,
- опубликовать сообщение в брокер,
- (опционально) ждать ACK/response и обновлять статус `Command`.

Пример:

```php
NodeCoordinator::sendCommand(Command $command)
{
    $topic = $this->topicBuilder->commandTopic(
        $command->zone_id,
        $command->node_id,
        $command->channel_name
    );

    $payload = $this->serializer->commandToJson($command);

    $this->mqttClient->publish($topic, $payload, $qos = 1, $retain = false);

    // далее можно либо ждать ответ, либо просто пометить SENT
}
```

#### 2.5.2. MQTT Listener / Router / Handlers

- `MqttListener`:
  - подключается к брокеру,
  - подписывается на группы топиков (telemetry/status/config_response/...),
  - передаёт все входящие MQTT сообщения в `MqttRouter`.

- `MqttRouter`:
  - разбирает topic вида:
    - `hydro/{gh}/{zone}/{node}/{channel}/{message_type}`,
  - инкапсулирует разворот:
    - gh_id, zone_id, node_id, channel_name, message_type,
  - отправляет в соответствующий handler:
    - `TelemetryHandler`, `StatusHandler`, `ConfigResponseHandler`, `CommandResponseHandler`, …

Пример:

```text
Topic: hydro/gh-1/zn-3/nd-ph-1/ch-ph_sensor/telemetry
```

В `TelemetryHandler`:

- валидация JSON,
- создание `TelemetrySample`,
- обновление кэша,
- возможный триггер AlertService.

---

## 3. Хранилище данных

Можно условно разделить:

1. **Реляционная БД (PostgreSQL/MySQL)**  
   - доменные сущности (Greenhouse, Zone, Recipes, Nodes, Channels, Cycles, Commands, Events, Alerts).

2. **Time-series хранилище (опционально)**  
   - если нужен очень подробный лог pH/EC/климата с высокой частотой — может использоваться отдельная TSDB (InfluxDB/TimescaleDB), либо те же PostgreSQL с оптимизацией.

3. **Кэш (Redis или аналог)**  
   - текущие значения телеметрии для быстрой отдачи в UI,
   - сохранение состояния зон/узлов для быстрого доступа планировщиком.

---

## 4. Потоки и взаимодействие с фронтом

### 4.1. Загрузка данных для UI

Пример: Страница “Zone Detail”.

API отдаёт:

- `Zone` (статичное описание),
- `ZoneRuntimeState` (фаза, состояние, последние целевые диапазоны),
- `last telemetry` по ключевым каналам (pH, EC, t°, RH, уровень, свет),
- `active alerts/events`,
- список `DeviceNode` + `DeviceChannel` для зоны,
- `upcoming cycles` (когда следующий запуск нутриентов/полива).

Фронт не общается с нодами напрямую — только через backend API/WebSocket.

---

### 4.2. Реалтайм обновления

При новых данных:

- TelemetryHandler пишет телеметрию в БД,
- обновляет кэш,
- публикует событие во внутренний EventBus,
- WebSocketGateway пушит обновление на UI:
  - обновить карты зон,
  - обновить графики,
  - показать алерт.

---

## 5. Роль ИИ относительно backend

В документах для ИИ нужно четко указать:

- **Где ИИ может вносить изменения:**
  - внутри контроллеров (алгоритмы принятия решений),
  - внутри RecipeService (генерация/оптимизация рецептов),
  - в логике Scheduler (выбор стратегий запуска),
  - в справочниках (Crop, Recipes, CycleDefinition).

- **Где ИИ не должен менять ядро без строгих правил:**
  - MqttClient, MqttListener, брокер,
  - базовая структура доменных сущностей (таблицы, связи),
  - низкоуровневые адаптеры к БД/кэшу.

- **Какие инварианты нужно сохранять:**
  - решения по управлению всегда проходят через Controller → Command → NodeCoordinator → MQTT → Node.
  - NodeConfig всегда описывается на backend.
  - Ноды никогда не становятся “умнее” backend’а.

---

## 6. План внедрения backend V3

1. **Добавить новые миграции и модели под домен V3**:
   - можно как отдельные таблицы (`zones_v3`, `recipes_v3`, ...), чтобы не ломать старую схему.

2. **Создать базовые Application Services**:
   - `ZoneService`, `RecipeService`, `DeviceNodeService`, `TelemetryService`.

3. **Внедрить MQTT Layer по паттерну MqttClientInterface + PhpMqttClient + Listener + Router + Handlers**.

4. **Реализовать NodeCoordinator**:
   - публикация команд и конфигов,
   - обработка ответов.

5. **Реализовать первый контроллер (например, нутриенты)**:
   - `ZoneNutrientController`.

6. **Включить Scheduler**:
   - запуск нутриентного контроллера по `ZoneCycleInstance`.

7. **Сверху — API и минимальный UI V3**:
   - для просмотра состояния зон,
   - для ручных действий (пауза/запуск, ручной полив, применение рецептов).

8. **Постепенная миграция старых зон/нод на новую архитектуру**.

---

Этот документ можно использовать как:

- основу для `/docs/BACKEND_ARCH_V3.md` в репозитории;
- инструкцию для ИИ-агентов по работе с backend-частью;
- базу для задач по реализации V3 backend’а (issue/epic в трекере).
