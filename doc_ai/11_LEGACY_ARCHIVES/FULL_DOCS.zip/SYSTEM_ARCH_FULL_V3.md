# SYSTEM_ARCH_FULL_V3.md
# Полная системная архитектура V3

(полный детализированный документ — генерация нового содержимого)

## 1. Цели системы
Система управляет теплицами через Backend, MQTT, узлы ESP32, UI и хранение данных. Главная идея — Backend‑центричная логика, а узлы — минимальные исполнители.

## 2. Слои архитектуры
- Physical Layer
- Device Layer (ESP32 Nodes)
- Transport Layer (Wi-Fi + MQTT)
- Logic Layer (Backend)
- Data Layer (DB + TSDB)
- Presentation Layer (Frontend)
- Intelligence Layer (AI)

## 3. Общая схема
Пользователь → Frontend → Backend → DB → MQTT → Узлы → Физические устройства.

## 4. Device Layer
Узлы ESP32 измеряют сенсоры и выполняют команды. Все операции стандартизированы:
- telemetry
- status/lwt
- config
- command
- command_response

## 5. Transport Layer
MQTT брокер обеспечивает надёжную доставку данных QoS=1. Wi‑Fi соединяет узлы с брокером.

## 6. Backend
Backend содержит бизнес‑логику:
- Zone Controllers
- Recipe Engine
- Cycle Scheduler
- Alerts/Events
- NodeConfig Manager
- NodeCoordinator (MQTT router)

## 7. Database Layer
- PostgreSQL/MySQL: хранение зон, нод, рецептов, циклов
- TSDB/Influx/Timescale: телеметрия
- Redis: быстрый кэш

## 8. Frontend
Современный UI с real‑time обновлениями:
- Zones/Zone Detail
- Devices
- Recipes
- Alerts
- Graphs
- Settings

## 9. Intelligence Layer
ИИ анализирует историю, рекомендует настройки, помогает оператору.

## 10. Потоки данных
### Telemetry Flow
node → mqtt → backend → db + cache → frontend(ws)

### Command Flow
backend → mqtt → node → command_response → backend

### Config Flow
backend → mqtt → node → config_response

### Status Flow
node → status/lwt → backend → alerts

## 11. Масштабирование
- горизонтальное масштабирование backend и брокера
- добавление новых зон и узлов без изменения протокола
- стабильный real‑time при десятках/сотнях нод

## 12. Надёжность
- LWT offline detection
- backend‑side timeouts
- безопасные таймеры в узлах
- автоматический reconnect Wi‑Fi/MQTT
- сохранение NodeConfig в NVS

## 13. Будущее развитие
- мульти‑тепличный режим
- кластеризация backend
- edge/cloud режим
- интеллектуальная автодиагностика
- система авто‑калибровок

## Конец файла
