# Архитектура логики V3 (Теплица → Зоны → Ноды)

Этот документ описывает **логическую архитектуру системы V3** для управления теплицей/фермой на базе ESP32 + MQTT + Backend.

Цель — дать **чёткий, формальный и понятный план**, по которому можно:

- проектировать backend,
- проектировать поведение нод,
- строить UI,
- обучать ИИ-агентов, как рефакторить и развивать систему.

---

## 1. Цели и принципы

### 1.1. Основные цели

1. Чётко разделить:

   - доменную модель (теплица, зоны, культуры, рецепты),
   - логику управления (контроллеры),
   - планировщик (циклы/таймеры),
   - транспорт (MQTT),
   - устройства (ESP‑ноды).

2. Сделать систему **масштабируемой**:
   - несколько теплиц,
   - десятки/сотни зон,
   - сотни нод.

3. Сделать устройства **простыми и предсказуемыми**:
   - нода = датчики + актуаторы,
   - никаких агрономических решений внутри ноды.

4. Сделать backend **единственным мозгом**:
   - все решения (pH, EC, полив, климат, свет, фазы роста) принимаются на backend.

---

### 1.2. Базовые принципы

- **Backend — источник правды.**
- **MQTT — единый шина-транспорт.**
- **Ноды — простые исполнители.**
- **Вся бизнес‑логика — в контроллерах и планировщике backend.**
- **Конфиги и рецепты — декларативны (через JSON/БД).**
- **Любое устройство описывается через каналы (Sensor/Actuator).**

---

## 2. Доменные сущности

### 2.1. Greenhouse (Теплица)

**Назначение:** контейнер для зон и устройств.

Поля (пример):

- `id`
- `name`
- `location` (регион, координаты, часовой пояс)
- `area_m2`
- `type` (GREENHOUSE / VERTICAL_FARM / CONTAINER)
- `description`

Связи:

- `Greenhouse hasMany Zone`
- `Greenhouse hasMany DeviceNode`

Backend не должен содержать тяжёлую логику в Greenhouse — это уровень агрономии и визуальной группировки.

---

### 2.2. Zone (Зона)

**Зона** — минимальная управляемая область с общим режимом.

Поля:

- `id`
- `greenhouse_id`
- `name`
- `zone_type`:
  - `PRODUCTION` (всё сразу — климат, полив, свет),
  - `NUTRIENT_TANK` (бак pH/EC),
  - `CLIMATE_ONLY`,
  - `IRRIGATION_ONLY`,
  - `LIGHTING_ONLY`,
  - `SERVICE`/`TECH`.
- `crop_id` — культура, которая выращивается (может быть `null` для техзон).
- `active_recipe_id` — какой рецепт применён.
- `current_phase_id` — фаза роста по рецепту (если есть).
- `state`:
  - `SETUP`,
  - `RUNNING`,
  - `PAUSED`,
  - `ALARM`,
  - `FINISHED`.
- `runtime_config` — скомпилированный JSON с целями и параметрами для нод.

Связи:

- `Zone hasMany DeviceNode`
- `Zone hasMany ZoneCycleInstance`
- `Zone belongsTo Recipe`
- `Zone hasMany TelemetrySample`
- `Zone hasMany ZoneEvent` (alarms, действия, переходы состояний)

---

### 2.3. DeviceNode и DeviceChannel

**DeviceNode** — логический узел (ESP32‑устройство).

Поля:

- `id`
- `zone_id` (может быть `null`, если общий ресурс — например, главный бак)
- `node_type` (PH_BOX, EC_BOX, CLIMATE_BOX, LIGHT_BOX, PUMP_BOX, MIXED и т.п.)
- `hw_model` (модель/ревизия платы)
- `fw_version`
- `status`:
  - `ONLINE`,
  - `OFFLINE`,
  - `DEGRADED`,
  - `UNKNOWN`.
- `last_seen_at`
- `ip_last_seen`
- `meta` (JSON: про железо, порты, особенности)

**DeviceChannel** — абстракция канала (сенсор или актуатор) внутри ноды.

Поля:

- `id`
- `node_id`
- `channel_name` (например, `"ph_sensor"`, `"pump_acid"`, `"fan_A"`)
- `channel_type`:
  - `SENSOR`,
  - `ACTUATOR`.
- `metric_type` (для сенсоров):
  - `PH`, `EC`, `TEMP_AIR`, `TEMP_WATER`, `HUMIDITY`, `LIGHT_LUX`, `WATER_LEVEL`, `FLOW_RATE`, `CO2`, ...
- `actuator_type` (для актуаторов):
  - `PUMP`, `VALVE`, `FAN`, `HEATER`, `LIGHT`, `RELAY`, `MIXER`, ...
- `safe_limits` (JSON: `max_duration_ms`, `min_off_time_ms`, `max_duty_cycle`, ...)
- `calibration_data` (JSON: калибровка для сенсоров).

Backend опирается на эти описания, а узлы получают **NodeConfig**, сгенерированный из `DeviceNode` + `DeviceChannel`.

---

### 2.4. Crop, Recipe (Preset), GrowthPhase

**Crop** — растение.

Поля:

- `id`, `name` (lettuce, basil, arugula, strawberry, ...)
- `description`
- общие агрономические рекомендации (опционально).

**Recipe** — рецепт выращивания для культуры.

Поля:

- `id`
- `crop_id`
- `name`
- `version`
- `description`
- список фаз (`GrowthPhase[]`)
- профили подсистем (по умолчанию для фаз).

**GrowthPhase** — фаза роста внутри рецепта.

Поля:

- `id`
- `recipe_id`
- `order` (0..N)
- `phase_name` (e.g. "seeding", "vegetative", "finish")
- `duration_days` (или альтернативные триггеры)
- целевые диапазоны:
  - `ph_min`, `ph_max`
  - `ec_min`, `ec_max`
  - `temp_air_min`, `temp_air_max`
  - `humidity_min`, `humidity_max`
  - `co2_min`, `co2_max` (опционально)
  - `light_hours`
  - `light_intensity` (если нужно)
- специальные параметры (например, “переходить на фазу 2 при высоте растения X” — в будущем для AI).

---

### 2.5. CycleDefinition и ZoneCycleInstance

**CycleDefinition** — описание “типового” цикла для подсистемы в рамках рецепта и фазы.

Поля:

- `id`
- `recipe_id`
- `phase_id`
- `subsystem`:
  - `PH`,
  - `EC`,
  - `CLIMATE`,
  - `IRRIGATION`,
  - `LIGHTING`,
  - `SERVICE`.
- `strategy`:
  - `PERIODIC`,
  - `EVENT_DRIVEN`,
  - `HYBRID`.
- `interval_sec` (для `PERIODIC`/`HYBRID`),
- `event_triggers` (для `EVENT_DRIVEN`/`HYBRID`: по какому событию/условию запускать).

**ZoneCycleInstance** — конкретный активный цикл в зоне.

Поля:

- `id`
- `zone_id`
- `cycle_definition_id`
- `next_run_at`
- `enabled`
- `last_run_at`
- `last_result` (успешно/ошибка/пропуск)

---

### 2.6. TelemetrySample, Command, ZoneEvent

**TelemetrySample** — запись телеметрии.

Поля:

- `id`
- `timestamp`
- `zone_id`
- `node_id`
- `channel_name`
- `metric_type`
- `value`
- `raw_payload` (JSON/строка, опционально)

**Command** — отправленная или запланированная команда ноде.

Поля:

- `id`
- `zone_id`
- `node_id`
- `channel_name`
- `command_type` (e.g. `RUN_PUMP`, `SET_PWM`, `SET_RELAY`, `REBOOT`, ...)
- `payload` (JSON)
- `status`:
  - `PENDING`,
  - `SENT`,
  - `ACK`,
  - `FAILED`,
  - `TIMEOUT`.
- `requested_at`
- `sent_at`
- `ack_at`

**ZoneEvent** — событие во времени.

Примеры:

- “pH скорректирован на +0.2 мл”,
- “Узел nd-ph-1 OFFLINE”,
- “Зона переведена в ALARM”,
- “Пользователь нажал manual irrigation”.

---

## 3. Слои логики Backend

Общая идея:

```text
API → Application Services → Domain Models → Controllers → Scheduler → NodeCoordinator → MQTT
```

### 3.1. API Layer

Отвечает за:

- REST API:
  - CRUD для Greenhouse/Zone/Recipe/DeviceNode,
  - действия с зонами (pause/resume, apply_recipe, change_phase),
  - действия с устройствами (test_channel).
- WebSocket/Server-Sent Events:
  - push‑обновления UI по зонам и устройствам.

API **не содержит бизнес‑логики**, только вызывает Application Services.

---

### 3.2. Application Services

Примеры сервисов:

- `GreenhouseService`
- `ZoneService`
- `RecipeService`
- `DeviceNodeService`
- `TelemetryService`
- `AlertService`

Назначение:

- инкапсулируют распространённые операции:
  - создание/изменение зон,
  - назначение рецепта зоне,
  - смена фазы,
  - регистрация ноды,
  - обработка входящей telemetry (сохранение и нормализация),
  - создание событий/алертов.

---

### 3.3. Domain Layer (модели)

Содержит:

- модели и их связи (см. раздел 2),
- инварианты (например, зона с `zone_type=NUTRIENT_TANK` не может иметь `crop_id`),
- простую доменную валидацию.

---

### 3.4. Контроллеры подсистем (Zone Controllers)

Для каждой подсистемы вводится отдельный контроллер:

- `ZoneClimateController`
- `ZoneNutrientController` (pH/EC)
- `ZoneIrrigationController`
- `ZoneLightingController`

**Входы:**

- `Zone` (состояние и runtime_config),
- активный `Recipe` и `GrowthPhase`,
- последние `TelemetrySample` по зонам и каналам,
- статус нод (ONLINE/OFFLINE/DEGRADED),
- конфигурация зон (ограничения, ручные режимы, overrides).

**Выходы:**

- **список команд** (Command) для `DeviceNode`/`DeviceChannel`,
- **обновлённое состояние зоны** (если есть переходы),
- **события** (ZoneEvent, Alert).

Пример: `ZoneNutrientController`:

1. Берёт последний `pH` и `EC` по баку (`zone_type=NUTRIENT_TANK`).
2. Сравнивает с целевыми диапазонами текущей фазы.
3. Если pH слишком низкий — рассчитывает дозу `pump_base` на N мл.
4. Если EC слишком низкий — рассчитывает дозу `pump_nutrient_A`.
5. Ставит команды в очередь (`Command`).
6. Логирует ZoneEvent.

---

### 3.5. Scheduler (Планировщик)

Назначение:

- запускать контроллеры по расписанию/событиям.

Алгоритм:

1. Каждую минуту (или другой базовый шаг):
   - выбрать все `ZoneCycleInstance`, где:
     - `enabled = true`,
     - `next_run_at <= now`.
2. Для каждого цикла:
   - определить `subsystem` (PH/EC/CLIMATE/IRRIGATION/LIGHTING).
   - вызвать соответствующий `ZoneXxxController`.
   - сохранить результат:
     - `last_run_at`,
     - `last_result`,
     - сдвинуть `next_run_at`.

Scheduler **не** знает агрономии — только запускает подсистемы.

---

### 3.6. NodeCoordinator

Назначение:

- интерфейс между логикой и MQTT‑слоем.

Функции:

- принимает запросы на отправку команд:
  - от контроллеров (через Application Services),
  - от UI (manual override).
- формирует MQTT‑сообщения в нужный формат (JSON),
- публикует их в нужные топики,
- отслеживает ответы и статусы команд (ACK/TIMEOUT),
- обновляет `Command.status`.

---

## 4. Потоки данных (Data Flows)

### 4.1. Поток телеметрии (снизу вверх)

1. Узел измеряет значения (pH/EC/климат/...).
2. Публикует MQTT telemetry:
   - topic: `hydro/{gh}/{zone}/{node}/{channel}/telemetry`.
   - payload: JSON (node_id, channel_name, metric_type, value, timestamp).
3. MQTT Listener на backend принимает сообщение.
4. MqttRouter перенаправляет его в `TelemetryHandler`.
5. `TelemetryHandler`:
   - валидирует payload,
   - сохраняет `TelemetrySample` в БД,
   - обновляет “current values” в кэше,
   - при необходимости:
     - триггерит оповещение (например, ALARM по выходу за диапазон),
     - пушит обновление в WebSocket для UI.

---

### 4.2. Поток управления (сверху вниз)

1. Scheduler запускает `ZoneXxxController` или пользователь нажимает кнопку в UI.
2. Контроллер формирует список `Command` объектов.
3. Application Service сохраняет `Command` в БД.
4. NodeCoordinator:
   - сериализует команду в JSON,
   - публикует в топик:
     - `hydro/{gh}/{zone}/{node}/{channel}/command`.
5. Узел получает команду → выполняет → при необходимости отправляет ответ/статус.
6. Backend (через MQTT Handler) обновляет `Command.status`.

---

### 4.3. Поток конфигурации узлов (NodeConfig)

1. Пользователь/ИИ меняет структуру устройств или настройки.
2. Backend пересобирает `NodeConfig` для ноды на основе:
   - `DeviceNode`,
   - `DeviceChannel`,
   - ZoneRuntimeConfig.
3. NodeCoordinator отправляет `config`:
   - topic: `hydro/{gh}/{zone}/{node}/config`.
4. Узел:
   - обновляет свои каналы,
   - сохраняет конфиг в NVS,
   - перезапускает внутренние циклы сенсоров.

---

### 4.4. Поток событий и алертов

1. Любой модуль (TelemetryHandler, ZoneController, NodeStatusHandler) может поднять `ZoneEvent`/`Alert`.
2. AlertService:
   - сохраняет событие,
   - при необходимости:
     - отправляет уведомление (email/telegram/...)
     - помечает зону как `ALARM`.
3. UI подписан на события и отображает их.

---

## 5. Состояния зоны (State Machine)

Примерная модель:

```text
      ┌──────────┐
      │  SETUP   │
      └────┬─────┘
           │ (apply recipe, config ok)
           ▼
      ┌──────────┐
      │ RUNNING  │◄───────────────┐
      └──┬───┬───┘                │
         │   │                    │
         │   │ (user: pause)      │
         │   ▼                    │
         │ ┌──────────┐           │
         │ │  PAUSED  │           │
         │ └────┬─────┘           │
         │      │ (resume)        │
         │      ▼                 │
         │                    ┌──────────┐
         │ (critical error)   │  ALARM   │
         └───────────────────▶└────┬─────┘
                                   │ (resolve/reset)
                                   ▼
                               back to RUNNING or SETUP
```

**Переходы:**

- `SETUP → RUNNING` — после применения корректного Recipe и успешной конфигурации нод.
- `RUNNING → PAUSED` — ручная пауза (например, обслуживание).
- `PAUSED → RUNNING` — ручное продолжение.
- `RUNNING/PAUSED → ALARM` — по критическим событиям (обрыв связи, выход параметров за опасные границы и т.д.).
- `ALARM → RUNNING/SETUP` — после устранения проблемы и подтверждения оператора/сервиса.

---

## 6. Роль ИИ в этой архитектуре

Для ИИ‑агентов нужно задать следующие правила:

1. **Что ИИ может менять:**
   - новые рецепты и фазы роста,
   - параметры циклов (CycleDefinition),
   - конфиги зон (назначение рецепт/культура),
   - структуру NodeConfig (если согласуется с DeviceChannel),
   - стратегию контроллеров (алгоритмы внутри `ZoneXxxController`).

2. **Чего ИИ не должен трогать:**
   - базовый MQTT‑слой (клиент/листенер/роутер),
   - низкоуровневые драйверы датчиков и исполнительных устройств,
   - инфраструктурные настройки сети (Wi‑Fi, репитеры, IP).

3. **Приоритет инвариантов:**
   - Нода не должна становиться “умнее” backend (никакой агрономии в ESP).
   - Все решения по pH/EC/поливу/климату — только backend.
   - Любая автоматизация должна быть обратимой и контролируемой через UI.

---

## 7. План внедрения (по шагам)

1. **Ввести доменную модель V3**:
   - создать таблицы/модели Greenhouse, Zone, DeviceNode, DeviceChannel, Crop, Recipe, GrowthPhase, CycleDefinition, ZoneCycleInstance, TelemetrySample, Command, ZoneEvent.

2. **Реализовать базовые Application Services**:
   - создание/редактирование зон, рецептов, нод, каналов.

3. **Реализовать MQTT‑слой (если ещё не сделано)**:
   - MqttClientInterface, PhpMqttClient,
   - MqttListener, MqttRouter, handlers.

4. **Реализовать Scheduler и NodeCoordinator**:
   - Scheduler — запуск контроллеров,
   - NodeCoordinator — отправка команд и конфигов.

5. **Реализовать хотя бы один контроллер**:
   - пример: `ZoneNutrientController` для pH/EC.

6. **Настроить TelemetryHandler**:
   - приём и сохранение телеметрии от нод,
   - обновление текущих значений.

7. **Добавить минимальный UI для зон**:
   - список зон,
   - карточка зоны (цели/фактические значения pH/EC/климата),
   - лог событий.

8. **Постепенно подключать остальные подсистемы**:
   - климат,
   - полив,
   - свет,
   - сервисные/алертные функции.

---

Этот документ можно использовать как **основной логический каркас V3** для:

- обсуждений архитектуры,
- постановки задач,
- настройки ИИ‑агентов,
- развития репозитория (backend, firmware, UI).
