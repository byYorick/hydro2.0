# Backend Архитектура V3

Слои:
- API
- Domain
- Controllers
- Scheduler
- NodeCoordinator
...