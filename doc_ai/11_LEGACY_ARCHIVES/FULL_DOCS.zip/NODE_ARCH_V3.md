# Архитектура Узлов (ESP32) V3

- WiFi STA → MQTT
- SensorChannels
- ActuatorChannels
- NodeConfig
- Telemetry
- LWT
...