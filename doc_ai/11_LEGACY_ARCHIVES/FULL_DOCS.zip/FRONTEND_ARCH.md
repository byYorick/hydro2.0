# Frontend Архитектура V3

Страницы:
- Greenhouses
- Zones
- Zone Detail
- Devices
- Recipes
- Alerts
...