# MQTT_SPEC_FULL_V3.md
# Полная MQTT спецификация V3 (Топики, Payload, Протоколы, Правила)

Этот документ описывает полный протокол MQTT для системы V3 управления теплицами.
Здесь указаны форматы топиков, JSON‑payload, правила QoS, LWT, NodeConfig, Telemetry,
Command, Responses и системные события.

---

# 1. Общая концепция MQTT V3

MQTT используется как **единая шина данных** между backend и ESP‑узлами (нодами).
Принципы:

- Backend — главный мозг. Узлы — исполнители.
- Модель: pub/sub, JSON‑payload.
- Все топики строго стандартизированы.
- Узлы используют только:
  - Telemetry → НАВЕРХ
  - Status/LWT → НАВЕРХ
  - Config/Command → ВНИЗ
- Backend слушает всё.
- Узлы подписываются только на свои config/command.

---

# 2. Структура MQTT-топиков V3

Формат топиков:

```
hydro/{ghid}/{zoneid}/{nodeid}/{channel}/{type}
```

Где:
- `ghid` — greenhouse ID (например gh-1)
- `zoneid` — zone ID (zn-3)
- `nodeid` — node ID (nd-ph-1)
- `channel` — имя канала (ph_sensor / pump_acid)
- `type` — тип сообщения:

Типы:
- **telemetry**
- **command**
- **command_response**
- **config**
- **config_response**
- **status**
- **lwt**

Пример:
```
hydro/gh-1/zn-3/nd-ph-1/ph_sensor/telemetry
```

---

# 3. Telemetry (узлы → backend)

## 3.1. Топик
```
hydro/{gh}/{zone}/{node}/{channel}/telemetry
```

## 3.2. Пример JSON
```json
{
  "node_id": "nd-ph-1",
  "channel": "ph_sensor",
  "metric_type": "PH",
  "value": 5.86,
  "raw": 1465,
  "timestamp": 1710001234
}
```

## 3.3. Requirements
- QoS = 1
- Retain = false
- Backend сохраняет TelemetrySample
- Backend обновляет last_value в Redis
- Backend может триггерить Alerts

---

# 4. Status & LWT (жизненный цикл узла)

## 4.1. LWT

Устанавливается при connect:

```
hydro/{gh}/{zone}/{node}/lwt
payload: "offline"
```

## 4.2. Online status
При успешном подключении узел публикует:

```
hydro/{gh}/{zone}/{node}/status
```

```json
{
  "status": "ONLINE",
  "ts": 1710001555
}
```

## 4.3. Offline
Отправляется брокером автоматически (LWT):

```
payload: "offline"
```

## 4.4. Backend действия:
- помечает ноду OFFLINE
- создаёт Alert
- Zone может перейти в ALARM

---

# 5. NodeConfig (backend → узлы)

## 5.1. Топик
```
hydro/{gh}/{zone}/{node}/config
```

## 5.2. Пример полного NodeConfig:
```json
{
  "node_id": "nd-ph-1",
  "version": 3,
  "channels": [
    {
      "name": "ph_sensor",
      "type": "SENSOR",
      "metric": "PH",
      "poll_interval_ms": 3000
    },
    {
      "name": "pump_acid",
      "type": "ACTUATOR",
      "actuator_type": "PUMP",
      "safe_limits": {
        "max_duration_ms": 5000,
        "min_off_ms": 3000
      }
    }
  ],
  "wifi": {
    "ssid": "HydroFarm",
    "pass": "12345678"
  },
  "mqtt": {
    "host": "192.168.1.10",
    "port": 1883,
    "keepalive": 30
  }
}
```

## 5.3. Requirements
- QoS = 1
- Retain = false
- Узел сохраняет конфиг в NVS
- Узел отправляет config_response

---

# 6. Config Response (узлы → backend)

## 6.1. Топик
```
hydro/{gh}/{zone}/{node}/config_response
```

## 6.2. Пример JSON
```json
{
  "status": "OK",
  "node_id": "nd-ph-1",
  "applied": true,
  "timestamp": 1710002222
}
```

Если ошибка:
```json
{
  "status": "ERROR",
  "error": "Invalid channel ph_sensor",
  "timestamp": 1710002223
}
```

---

# 7. Commands (backend → узлы)

## 7.1. Топик
```
hydro/{gh}/{zone}/{node}/{channel}/command
```

## 7.2. Пример команд

### 1) Пуск насоса
```json
{
  "cmd": "run_pump",
  "duration_ms": 2500,
  "cmd_id": "cmd-591"
}
```

### 2) Включение реле
```json
{
  "cmd": "set_relay",
  "state": true,
  "cmd_id": "cmd-592"
}
```

### 3) PWM
```json
{
  "cmd": "set_pwm",
  "value": 128,
  "cmd_id": "cmd-593"
}
```

### 4) Калибровка
```json
{
  "cmd": "calibrate",
  "type": "PH_7",
  "cmd_id": "cmd-594"
}
```

---

# 8. Command Response (узлы → backend)

## 8.1. Топик
```
hydro/{gh}/{zone}/{node}/{channel}/command_response
```

## 8.2. Payload
```json
{
  "cmd_id": "cmd-591",
  "status": "ACK",
  "ts": 1710003333
}
```

Статусы:
- ACK  
- ERROR  
- TIMEOUT (узел шлёт сам при ошибке операции)

---

# 9. Дополнительные системные топики

## 9.1. Heartbeat узла
```
hydro/{gh}/{zone}/{node}/heartbeat
```

```json
{
  "uptime": 35555,
  "free_heap": 102000,
  "rssi": -62
}
```

## 9.2. Debug (опционально)
```
hydro/{node}/debug
```

---

# 10. Правила QoS и Retain

| Тип | QoS | Retain |
|-----|-----|---------|
| telemetry | 1 | false |
| command | 1 | false |
| command_response | 1 | false |
| config | 1 | false |
| config_response | 1 | false |
| status | 1 | true |
| lwt | 1 | true |
| heartbeat | 0 | false |

---

# 11. Правила именования

### Node ID
```
nd-{type}-{nn}
```
Примеры:
- `nd-ph-1`
- `nd-ec-2`

### Channel ID
```
ph_sensor
ec_sensor
pump_acid
pump_base
fan_A
heater_1
```

---

# 12. Потоки данных (Data Flows)

## Telemetry → Backend
```
node → mqtt → listener → router → handler → TelemetryService
```

## Command → Node
```
controller → CommandService → NodeCoordinator → mqtt → node
```

## Config → Node
```
backend → mqtt → node → config_response
```

## Status → Backend
```
node → status/lwt → backend → AlertService
```

---

# 13. Требования к узлам (Node Firmware)

- подписка на:
  - `{node}/config`
  - `{node}/{channel}/command`
- публикация:
  - telemetry
  - status
  - command_response
  - config_response
  - lwt

- JSON строго формализован
- Ошибки всегда возвращаются через command_response

---

# 14. Требования к backend

- полный MQTT router
- QoS = 1
- хранение команд
- таймаут команд (если нет ACK)
- NodeConfig пересылать при изменениях
- алерты при offline / telemetry out of range

---

# 15. Будущее расширение (V4)

- групповые команды
- топики для AI-моделей
- нормализация telemetry через schema registry
- агрономические триггеры MQTT→backend
- автоматические профили нод

---

# Конец файла
