# DEVICE_NODE_PROTOCOL_V3.md
# Полная спецификация протокола узлов ESP32 (V3)
# Инструкция для ИИ-агентов и разработчиков прошивок

Этот документ описывает стандарты, обязательные правила и архитектуру прошивок узлов ESP32 для гидропонной системы V3.  
Цель — обеспечить абсолютную совместимость узлов с Python-сервисом, Laravel, MQTT-топиками и БД.

---

# 1. Основные принципы

Узел ESP32 обязан:

- идентифицировать себя по стандарту V3;
- публиковать telemetry, status, command_response;
- принимать команды «command» в одном формате;
- соблюдать топик-структуру;
- иметь устойчивую работу в условиях сетевых потерь;
- поддерживать OTA (опционально, позже);
- работать автономно с локальными тайм‑аутами.

ИИ-агенты **не имеют права менять** format, naming и структуру ключевых сообщений.

---

# 2. Иерархия идентификаторов узлов

Каждый ESP32 получает:

- `greenhouse_id` (gh‑1)
- `zone_id` (zn‑3)
- `node_id` (nd‑ph‑1, nd‑ec‑2, nd‑irrig‑1)

Правило:
- node_id = тип + порядковый номер  
  Примеры:
  - nd-ph-1 (pH сенсор)
  - nd-ec-1 (EC сенсор)
  - nd-irrig-1 (насосы/клапаны)
  - nd-climate-1 (датчики климата)

---

# 3. MQTT топики (обязательный формат)

```
hydro/{gh}/{zone}/{node}/{channel}/{type}
```

Пример:

```
hydro/gh-1/zn-2/nd-ph-1/ph_sensor/telemetry
```

**Менять формат запрещено.**

---

# 4. Сообщения от узла

## 4.1. Telemetry

**Topic:**
```
hydro/gh/zone/node/channel/telemetry
```

**Payload:**
```json
{
  "value": 6.42,
  "ts": 1737355600456
}
```

Требования:

- value — float или int, не объект.
- ts — UNIX‑timestamp в миллисекундах (uint64).
- канал channel = одно из:
  - ph_sensor
  - ec_sensor
  - temp_air
  - humidity_air
  - temp_water
  - water_level
  - light_sensor
  - custom_xxx (если расширяем)

## 4.2. Status (жизненный статус узла)

**Topic:**
```
hydro/gh/zone/node/status
```

**Payload:**
```json
{
  "online": true,
  "ip": "192.168.1.44",
  "rssi": -62,
  "fw": "1.0.3"
}
```

Минимум каждые **60 секунд** узел обязан публиковать status.

## 4.3. command_response

Узел обязан отвечать на команду Python‑сервиса.

**Topic:**
```
hydro/gh/zone/node/channel/command_response
```

**Payload:**
```json
{
  "cmd_id": "cmd-91ab23",
  "status": "ACK",
  "details": "OK"
}
```

Статусы:
- ACK
- ERROR
- INVALID
- BUSY
- NO_EFFECT

Узел обязан отправить command_response в течение 5 секунд после выполнения.

---

# 5. Сообщения к узлу (команды)

Python-сервис отправляет команды:

**Topic:**
```
hydro/gh/zone/node/channel/command
```

**Payload:**
```json
{
  "cmd_id": "cmd-123abc",
  "cmd": "dose",
  "params": {
    "ml": 0.5
  }
}
```

Обязательные поля:
- cmd_id — строка UUID/HEX
- cmd — имя команды
- params — JSON-объект

Узел обязан:

1. принять команду;
2. выполнить её (или отказать корректно);
3. вернуть command_response с тем же cmd_id.

---

# 6. Типы каналов узла

Узел формируется из **каналов** — логических единиц.

## 6.1. SENSOR каналы:

| Канал          | Тип значения | Связь с БД |
|----------------|--------------|------------|
| ph_sensor      | float        | metric=PH  |
| ec_sensor      | float        | metric=EC  |
| temp_air       | float        | TEMP_AIR   |
| humidity_air   | float        | HUMIDITY   |
| temp_water     | float        | TEMP_WATER |
| water_level    | float/int    | LEVEL      |
| light_sensor   | float/int    | LIGHT      |

Сенсоры публикуют telemetry.

## 6.2. ACTUATOR каналы:

| Канал            | Тип действия |
|------------------|--------------|
| pump_acid        | дозирование кислоты |
| pump_base        | дозирование щёлочи |
| pump_nutrient    | внесение удобрений |
| pump_irrigation  | полив |
| valve_irrigation | клапан |
| fan_air          | вентилятор |
| heater_air       | подогрев |
| white_light      | освещение |
| uv_light         | УФ-лампы |

Актуация идёт только через `command`.

---

# 7. Жизненный цикл узла

1. **Boot** — узел подключается к Wi‑Fi.
2. **MQTT connect**
3. Публикация:
   - `status` (online=true)
4. Загрузка локальной конфигурации.
5. Публикация первых telemetry.
6. Работа цикла:
   - сенсоры → telemetry каждые X секунд,
   - статус каждые 60 секунд,
   - выполнение команд,
   - command_response.

Если Wi-Fi пропадает → узел копит telemetry максимум 10 записей и публикует после восстановления.

---

# 8. Ошибки и отказоустойчивость

Узел должен поддерживать:

- автоматический reconnect MQTT (esp-mqtt builtin);
- watchdog 5–10 секунд;
- локальные тайм-ауты для команд;
- очередь «pending commands» max 5 шт.;
- защиту от двойных команд (повторные cmd_id игнорировать).

---

# 9. Минимальные требования к прошивке

### Стэк:
- ESP-IDF или Arduino-ESP32;
- mqtt client;
- json (cJSON, ArduinoJson);
- wifi reconnect логика.

### Память:
- heap min 80 KB free
- минимизация логирования

### Производительность:
- отправка telemetry не чаще чем 1 раз / 300 мс на канал (рекомендация)
- отправка status 1 раз в минуту

---

# 10. Правила для ИИ-агентов

ИИ-агент **может**:

- добавлять новые каналы (SENSOR/ACTUATOR);
- расширять config_response;
- улучшать алгоритмы обработки команд;
- добавлять OTA-поддержку;
- добавлять калибровку.

ИИ-агент **не может**:

- менять формат MQTT-топиков,
- менять ключи telemetry (`value`, `ts`),
- менять структуру команд (`cmd_id`, `cmd`, `params`),
- менять command_response,
- менять обязательные каналы (ph_sensor, ec_sensor).

---

# 11. Чек-лист ИИ перед изменением протокола

1. Формат топиков не изменён?
2. Telemetry всё ещё `{value, ts}`?
3. Команда всё ещё `{cmd_id, cmd, params}`?
4. Ответ содержит `cmd_id`?
5. Backward compatibility соблюдена?
6. Python и Laravel смогут обработать новый канал/тип?
7. Узел не начнёт отправлять слишком частые сообщения?

---

# Конец файла DEVICE_NODE_PROTOCOL_V3.md
