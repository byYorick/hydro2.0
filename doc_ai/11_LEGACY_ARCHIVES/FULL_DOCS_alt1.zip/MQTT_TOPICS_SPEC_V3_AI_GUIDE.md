# MQTT_TOPICS_SPEC_V3_AI_GUIDE.md
# Полная спецификация MQTT топиков и payload для V3 гидропонной системы
# Инструкция для ИИ-агентов

Этот документ описывает **всю структуру MQTT-трафика**,  
который используется узлами ESP32, Python-сервисом и Laravel UI.

ИИ-агенты должны **строго соблюдать формат топиков и payload**,  
так как изменение структуры нарушит совместимость узлов и сервисов.

---

# 1. Общая структура MQTT-топика

Все топики следуют паттерну формата:

```
hydro/{greenhouse_id}/{zone_id}/{node_id}/{channel}/{message_type}
```

Где:

| Поле             | Описание |
|------------------|----------|
| `greenhouse_id`  | ID теплицы (gh-1, gh-main, gh-a) |
| `zone_id`        | ID зоны (zn-1, zn-5 и т.п.) |
| `node_id`        | ID узла ESP32 (nd-ph-1, nd-ec-2, nd-climate-1) |
| `channel`        | Логическое имя сенсора/актуатора (ph_sensor, pump_acid, fan, t_sensor) |
| `message_type`   | Вид сообщения (`telemetry`, `status`, `command_response`, `config_response`) |

**ИИ-агент не имеет права менять этот формат.**

---

# 2. Категории MQTT сообщений

## 2.1. Telemetry (основная телеметрия)

**Topic:**
```
hydro/{gh}/{zone}/{node}/{channel}/telemetry
```

**Payload:**
```json
{
  "value": 6.35,
  "ts": 1737355600456
}
```

Правила:
- `value` — только число (float/int).
- `ts` — всегда UNIX timestamp в миллисекундах.
- Дополнительные поля добавлять **нельзя** — только в новом message_type.

---

## 2.2. Status (жизненный статус узла)

**Topic:**
```
hydro/{gh}/{zone}/{node}/status
```

**Payload:**
```json
{
  "online": true,
  "ip": "192.168.1.87",
  "rssi": -63,
  "fw": "1.0.4"
}
```

Правила:
- Если узел использует LWT (Last Will), payload может быть:
```json
{ "online": false }
```
- Python-сервис обязан обновить:
  - `device_nodes.status`
  - `device_nodes.wifi_rssi`
  - `device_nodes.last_seen_at`

ИИ-агент **не должен менять значения ключей** (`online`, `ip`, `rssi`, `fw`).

---

## 2.3. command_response

Узел ESP32 отвечает на команду, отправленную Python-сервисом.

**Topic:**
```
hydro/{gh}/{zone}/{node}/{channel}/command_response
```

**Payload:**
```json
{
  "cmd_id": "cmd-23b91a",
  "status": "ACK",
  "details": "OK"
}
```

Допустимые статусы:
- `ACK`
- `ERROR`
- `INVALID`
- `BUSY`
- `NO_EFFECT` (команда принята, но не вызвала действия)

Python обновляет:

```
commands.status = ACK|ERROR|...
commands.updated_at = now()
```

ИИ не должен менять:
- формат `cmd_id`,
- имена статусов.

---

## 2.4. config_response

Используется при загрузке конфигурации в узел.

**Topic:**
```
hydro/{gh}/{zone}/{node}/config_response
```

**Payload:**
```json
{
  "config": "accepted",
  "fw": "1.0.5"
}
```

---

# 3. Направление сообщений

## 3.1. Узлы → MQTT → Python

Узел публикует:

- telemetry
- status
- command_response

Python слушает всё через подписку `hydro/#`.

---

## 3.2. Python → MQTT → Узлы (команды)

Формат топика:

```
hydro/{gh}/{zone}/{node}/{channel}/command
```

**Payload:**
```json
{
  "cmd_id": "cmd-ab12cd",
  "cmd": "dose",
  "params": {
    "ml": 0.5
  }
}
```

Строгие правила:
1. `cmd_id` генерирует Python.
2. Узел обязан вернуть `command_response` с тем же `cmd_id`.
3. `params` всегда объект JSON.

**Нельзя менять структуру.**

---

# 4. Каналы (channel) — список

ESP32 узлы имеют каналы:

## СЕНСОРЫ:
- `ph_sensor`
- `ec_sensor`
- `temp_air`
- `humidity_air`
- `temp_water`
- `water_level`
- `light_sensor`

## АКТУАТОРЫ:
- `pump_acid`
- `pump_base`
- `pump_nutrient`
- `pump_irrigation`
- `fan_air`
- `heater_air`
- `uv_light`
- `white_light`
- `valve_irrigation`
- `cooler`
- `co2_valve`

ИИ-агент **может добавлять** новые каналы, но:
- `type` определяется на стороне Laravel/DB,
- payload должен оставаться стандартным.

---

# 5. Полный свод правил для ИИ

### 5.1. ИИ-агент может:
- добавлять новые message_type (например `calibration`),
- добавлять новые каналы,
- улучшать структуру Python-обработчиков,
- создавать новые команды.

### 5.2. ИИ-агент НЕ должен:
- менять базовый формат топика,
- менять названия существующих message_type,
- менять структуру существующих payload,
- добавлять новые ключи в telemetry payload,
- менять значение `value` на объект (должен быть float).

### 5.3. ИИ-агент должен:
- соблюдать стандарты JSON,
- обеспечивать парность `command` → `command_response`,
- не смешивать разные типы сообщений,
- использовать MQTT QoS = 1 или 0 (не 2).

---

# 6. Примеры “правильных” сообщений

## 6.1. Telemetry pH
```
hydro/gh-1/zn-4/nd-ph-1/ph_sensor/telemetry
{"value":5.89,"ts":1737355000123}
```

## 6.2. Telemetry EC
```
hydro/gh-1/zn-4/nd-ec-1/ec_sensor/telemetry
{"value":1.22,"ts":1737355224111}
```

## 6.3. Команда на насос
```
hydro/gh-1/zn-2/nd-irrig-1/pump_irrigation/command
{"cmd_id":"cmd-123","cmd":"run","params":{"duration_ms":3000}}
```

## 6.4. Ответ узла
```
hydro/gh-1/zn-2/nd-irrig-1/pump_irrigation/command_response
{"cmd_id":"cmd-123","status":"ACK","details":"done"}
```

---

# 7. Чек‑лист для ИИ перед изменением MQTT

1. Затрагивает ли изменение существующие топики? → нельзя менять.
2. Payload остаётся совместимым? → если нет, недопустимо.
3. Python сможет обработать новый тип? → если нет, нужно расширить router.
4. Узлы ESP смогут понять команду? → структура команды неизменна.
5. Laravel сможет показывать новые данные? → расширить модели.

---

# Конец файла MQTT_TOPICS_SPEC_V3_AI_GUIDE.md
