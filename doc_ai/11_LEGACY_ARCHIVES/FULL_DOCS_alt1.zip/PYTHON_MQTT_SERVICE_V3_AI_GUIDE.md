# PYTHON_MQTT_SERVICE_V3_AI_GUIDE.md
# Детальная инструкция для ИИ-агентов по Python MQTT-сервису
# Архитектура V3 гидропонной теплицы

Этот документ обучает ИИ-агентов тому, как **правильно работать с Python-сервисом**, который отвечает за:

- чтение MQTT-трафика узлов (ESP32),
- запись телеметрии в PostgreSQL,
- работу контроллеров зон (pH, EC, климат, полив, свет),
- генерацию и выполнение команд,
- генерацию событий и алертов.

Python-сервис — это «ядро логики» и должен оставаться строгим, предсказуемым и стабильным.

---

# 1. Общая архитектура Python-сервиса

Python-часть системы состоит из двух основных процессов:

## 1. MQTT Listener (main_mqtt.py)
Задачи:
- подписка на все топики `hydro/#`;
- разбор структуры топиков;
- вызов соответствующих обработчиков;
- запись телеметрии в БД;
- статус узлов;
- обновление команд.

Используем async-библиотеку:
- `asyncio-mqtt` или `gmqtt`

---

## 2. Scheduler / Controllers (main_scheduler.py)

Задачи:
- запуск контроллеров зон
- расчёт отклонений от целевых параметров
- формирование команд
- отправка команд в MQTT
- обновление статусов команд в БД

Работает циклически каждые 3–10 секунд.

---

# 2. Структура файлов (обязательная для ИИ)

```text
backend-python/
  app/
    mqtt/
      client.py
      router.py
      topics.py
      handlers/
        telemetry.py
        status.py
        command_response.py
        config_response.py
    controllers/
      nutrient.py
      ec.py
      climate.py
      irrigation.py
      lighting.py
      scheduler.py
    db/
      session.py
      models.py
      queries.py
    ai/
      analyzer.py
    utils/
      logger.py
  main_mqtt.py
  main_scheduler.py
  requirements.txt
```

ИИ-агенты **должны соблюдать** эту структуру и не ломать пути к файлам.

---

# 3. Формат MQTT-топиков

Формат един для всех узлов:

```
hydro/{greenhouse_id}/{zone_id}/{node_id}/{channel}/{type}
```

Типы сообщений:
- telemetry
- status
- command_response
- config_response

ИИ-агенты **не имеют права менять структуру топиков**.

---

# 4. MQTT Listener — main_mqtt.py

```python
import asyncio
from app.mqtt.client import MQTTClient
from app.mqtt.router import MQTTRouter

async def main():
    router = MQTTRouter()
    client = MQTTClient(router)
    await client.connect()
    await client.subscribe("hydro/#")
    await client.listen()

asyncio.run(main())
```

ИИ-агенты не должны:
- добавлять блокирующие операции,
- изменять сигнатуру `main()`.

---

# 5. Router (маршрутизатор MQTT)

Файл: `app/mqtt/router.py`

```python
class MQTTRouter:
    def __init__(self):
        from app.mqtt.handlers.telemetry import TelemetryHandler
        from app.mqtt.handlers.status import StatusHandler
        from app.mqtt.handlers.command_response import CommandResponseHandler
        from app.mqtt.handlers.config_response import ConfigResponseHandler

        self.handlers = {
            "telemetry": TelemetryHandler(),
            "status": StatusHandler(),
            "command_response": CommandResponseHandler(),
            "config_response": ConfigResponseHandler(),
        }

    async def handle(self, topic, payload):
        parts = topic.split("/")
        message_type = parts[-1]

        if message_type in self.handlers:
            await self.handlers[message_type].handle(parts, payload)
```

ИИ-агенты могут **добавлять новые message_type**, но не ломать существующие.

---

# 6. Обработчик Telemetry

Файл: `app/mqtt/handlers/telemetry.py`

Задачи:

1. Распарсить топик.
2. Сохранить сырые данные в `telemetry_samples`.
3. Обновить `telemetry_last`.
4. Генерировать `ZoneEvents` при аномалиях.
5. Ничего не считать — расчёты выполняет контроллер зоны.

Пример:

```python
class TelemetryHandler:
    async def handle(self, parts, payload):
        gh_id, zone_id, node_id, channel = parts[1], parts[2], parts[3], parts[4]
        data = json.loads(payload)

        save_sample(zone_id, node_id, channel, data["value"], data["ts"])
        update_last(zone_id, node_id, channel, data["value"])
        analyze_telemetry(zone_id, channel, data["value"])
```

ИИ-агент никогда не меняет:

- формат payload,
- key `"value"`.

---

# 7. Команды узлам — lifecycle

Команда создаётся в Laravel → Python её выполняет.

Состояния:
- QUEUED
- SENT
- ACK
- ERROR
- TIMEOUT

Python-логика:

```python
cmd_id = create_command(...)
publish_mqtt(zone, node, channel, cmd_id, ...)
update_status(cmd_id, "SENT")
```

При ответе узла:

```python
def handle_response(data):
    update_status(data["cmd_id"], data["status"])
```

ИИ-агент обязан соблюдать этот жизненный цикл.

---

# 8. Scheduler и контроллеры

Главный цикл:

```python
async def main():
    while True:
        zones = db.get_active_zones()
        for zone in zones:
            nutrient.run(zone)
            ec.run(zone)
            climate.run(zone)
            irrigation.run(zone)
            lighting.run(zone)

        await asyncio.sleep(5)
```

ИИ-агент должен:

- соблюдать async‑подход,  
- не вносить синхронные блокировки.

---

# 9. Контроллер pH — пример

Файл: `controllers/nutrient.py`

```python
class NutrientController:
    def run(self, zone):
        current_ph = get_last_metric(zone.id, "ph_sensor")
        target_ph = zone.recipe_instance.targets["ph"]

        if current_ph > target_ph + 0.2:
            create_command(
                zone.id,
                get_ph_doser_node(zone),
                "acid_pump",
                "dose",
                {"ml": 0.5},
            )
```

**ИИ-агент может:**
- улучшать алгоритм,
- добавлять хистерезис,
- делать adaptive thresholds.

**ИИ-агент не должен:**
- менять структуру команд,
- менять принципы работы Scheduler.

---

# 10. База данных — правила

Python-сервис работает через:

```python
from app.db.session import db
```

ИИ-агент должен:
- использовать только функции из `queries.py`,
- не делать сырые SQL без причины.

---

# 11. Чек-лист для ИИ-агента

Перед изменением:

1. Это обработчик MQTT? контроллер? логика БД?
2. Формат топиков остаётся прежним?
3. Формат команд — прежний?
4. Команда проходит переходы QUEUED→SENT→ACK/ERROR?
5. Контроллеры работают только через `TelemetryLast`, а не напрямую из MQTT?
6. Не блокируется ли главный цикл?
7. Нет ли SQL-инъекций? (даже внутренне)
8. Файлы лежат в правильных директориях.

---

# Конец файла PYTHON_MQTT_SERVICE_V3_AI_GUIDE.md
