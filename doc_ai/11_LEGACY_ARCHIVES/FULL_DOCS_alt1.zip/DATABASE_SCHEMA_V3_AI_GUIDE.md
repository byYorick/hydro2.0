# DATABASE_SCHEMA_V3_AI_GUIDE.md
# Детальная инструкция для ИИ-агентов по схеме БД
# PostgreSQL для V3 гидропонной теплицы (Laravel + Python + MQTT)

Этот документ описывает **логическую схему базы данных** для V3-проекта
и правила, как ИИ-агенты должны с ней работать.

БД общая для:
- Laravel backend (доменная модель, UI, API),
- Python-сервиса (MQTT, контроллеры),
- аналитики (Grafana и т.п.).

---

## 1. Общие принципы

1. **Единый источник истины** — PostgreSQL.
2. Laravel — основной владелец схемы:
   - миграции создаются в Laravel;
   - Python-сервис использует уже готовую схему.
3. Никаких “плавающих” полей:
   - чёткие типы,
   - чёткие связи (FK там, где это безопасно).
4. Telmetry:
   - подробная история — в `telemetry_samples`;
   - последние значения — в `telemetry_last` (таблица или materialized view).

ИИ-агенты **не должны ломать существующие таблицы**,  
но могут предлагать новые, расширением, а не ломкой.

---

## 2. Список ключевых таблиц

1. `greenhouses` — теплицы.
2. `zones` — зоны внутри теплиц.
3. `device_nodes` — узлы ESP32.
4. `device_channels` — каналы узлов (сенсоры и актуаторы).
5. `recipes` — рецепты.
6. `growth_phases` — фазы рецептов.
7. `zone_recipe_instances` — активные рецепты для зоны.
8. `telemetry_samples` — история телеметрии.
9. `telemetry_last` — последние значения телеметрии.
10. `commands` — команды к узлам.
11. `zone_events` — события зон.
12. `alerts` — алерты.
13. (опционально) `users`, `roles`, `settings` — для UI/прав.

---

## 3. Таблицы доменной модели

### 3.1. Таблица `greenhouses`

```sql
CREATE TABLE greenhouses (
  id          BIGSERIAL PRIMARY KEY,
  name        VARCHAR(255) NOT NULL,
  location    VARCHAR(255),
  created_at  TIMESTAMP(0) WITH TIME ZONE,
  updated_at  TIMESTAMP(0) WITH TIME ZONE
);
```

Используется как верхний уровень: одна или несколько теплиц.

---

### 3.2. Таблица `zones`

```sql
CREATE TABLE zones (
  id                   BIGSERIAL PRIMARY KEY,
  gh_id                BIGINT REFERENCES greenhouses(id) ON DELETE CASCADE,
  name                 VARCHAR(255) NOT NULL,
  status               VARCHAR(32) NOT NULL DEFAULT 'PAUSED', -- RUNNING/PAUSED/ALARM/WARNING
  recipe_instance_id   BIGINT, -- FK на zone_recipe_instances.id (по желанию)
  created_at           TIMESTAMP(0) WITH TIME ZONE,
  updated_at           TIMESTAMP(0) WITH TIME ZONE
);
```

Индексы:
- `INDEX zones_gh_id_index (gh_id);`

---

### 3.3. Таблица `device_nodes`

```sql
CREATE TABLE device_nodes (
  id           BIGSERIAL PRIMARY KEY,
  zone_id      BIGINT REFERENCES zones(id) ON DELETE SET NULL,
  node_key     VARCHAR(64) NOT NULL,       -- логический ID (nd-ph-1 и т.п.)
  type         VARCHAR(32) NOT NULL,       -- PH/EC/CLIMATE/IRRIG/LIGHT/OTHER
  status       VARCHAR(32) NOT NULL DEFAULT 'OFFLINE',
  wifi_rssi    INTEGER,
  hw_version   VARCHAR(64),
  fw_version   VARCHAR(64),
  last_seen_at TIMESTAMP(0) WITH TIME ZONE,
  created_at   TIMESTAMP(0) WITH TIME ZONE,
  updated_at   TIMESTAMP(0) WITH TIME ZONE
);
```

Индексы:
- `UNIQUE (node_key);`
- `INDEX device_nodes_zone_id_index (zone_id);`

---

### 3.4. Таблица `device_channels`

```sql
CREATE TABLE device_channels (
  id             BIGSERIAL PRIMARY KEY,
  node_id        BIGINT REFERENCES device_nodes(id) ON DELETE CASCADE,
  name           VARCHAR(64) NOT NULL,       -- ph_sensor, pump_acid, fan, ...
  type           VARCHAR(16) NOT NULL,       -- SENSOR / ACTUATOR
  metric         VARCHAR(32),                -- PH/EC/TEMP/HUM/RSSI/FLOW/...
  actuator_type  VARCHAR(32),                -- PUMP/VALVE/FAN/RELAY/PWM
  created_at     TIMESTAMP(0) WITH TIME ZONE,
  updated_at     TIMESTAMP(0) WITH TIME ZONE
);
```

Индексы:
- `INDEX device_channels_node_id_index (node_id);`

---

## 4. Таблицы рецептов

### 4.1. Таблица `recipes`

```sql
CREATE TABLE recipes (
  id          BIGSERIAL PRIMARY KEY,
  name        VARCHAR(255) NOT NULL,
  crop_type   VARCHAR(128),
  notes       TEXT,
  created_at  TIMESTAMP(0) WITH TIME ZONE,
  updated_at  TIMESTAMP(0) WITH TIME ZONE
);
```

### 4.2. Таблица `growth_phases`

```sql
CREATE TABLE growth_phases (
  id             BIGSERIAL PRIMARY KEY,
  recipe_id      BIGINT REFERENCES recipes(id) ON DELETE CASCADE,
  phase_key      VARCHAR(64) NOT NULL, -- seedling, veg, bloom...
  name           VARCHAR(255) NOT NULL,
  order_index    INTEGER NOT NULL DEFAULT 0,
  duration_hours INTEGER,
  targets        JSONB,                -- { "ph": 5.8, "ec": 1.6, "temp_air": 23, ... }
  created_at     TIMESTAMP(0) WITH TIME ZONE,
  updated_at     TIMESTAMP(0) WITH TIME ZONE
);
```

Индексы:
- `INDEX growth_phases_recipe_id_index (recipe_id);`

### 4.3. Таблица `zone_recipe_instances`

```sql
CREATE TABLE zone_recipe_instances (
  id               BIGSERIAL PRIMARY KEY,
  zone_id          BIGINT REFERENCES zones(id) ON DELETE CASCADE,
  recipe_id        BIGINT REFERENCES recipes(id) ON DELETE CASCADE,
  current_phase_id BIGINT REFERENCES growth_phases(id),
  started_at       TIMESTAMP(0) WITH TIME ZONE,
  phase_started_at TIMESTAMP(0) WITH TIME ZONE,
  created_at       TIMESTAMP(0) WITH TIME ZONE,
  updated_at       TIMESTAMP(0) WITH TIME ZONE
);
```

Индексы:
- `UNIQUE (zone_id);`

---

## 5. Telemetry

### 5.1. Таблица `telemetry_samples`

Эта таблица может быть **очень большой**.

```sql
CREATE TABLE telemetry_samples (
  id           BIGSERIAL PRIMARY KEY,
  zone_id      BIGINT REFERENCES zones(id) ON DELETE CASCADE,
  node_id      BIGINT REFERENCES device_nodes(id) ON DELETE SET NULL,
  channel      VARCHAR(64) NOT NULL,
  metric_type  VARCHAR(32) NOT NULL,        -- PH/EC/TEMP/HUM/...
  value        DOUBLE PRECISION NOT NULL,
  raw          INTEGER,
  ts           TIMESTAMP(3) WITH TIME ZONE NOT NULL
);
```

Индексы:
- `INDEX telemetry_samples_zone_ts (zone_id, ts);`
- `INDEX telemetry_samples_metric_ts (metric_type, ts);`

Важно для ИИ:
- не добавлять лишние поля в эту таблицу без необходимости;
- помнить о её размере (использовать архивацию/retention при необходимости).

---

### 5.2. Таблица или view `telemetry_last`

Вариант 1 — materialized view (логический пример):

```sql
CREATE MATERIALIZED VIEW telemetry_last AS
SELECT DISTINCT ON (zone_id, metric_type)
  zone_id, node_id, channel, metric_type, value, ts AS updated_at
FROM telemetry_samples
ORDER BY zone_id, metric_type, ts DESC;
```

Вариант 2 — обычная таблица, которую Python обновляет явно:

```sql
CREATE TABLE telemetry_last (
  id           BIGSERIAL PRIMARY KEY,
  zone_id      BIGINT REFERENCES zones(id) ON DELETE CASCADE,
  node_id      BIGINT REFERENCES device_nodes(id) ON DELETE SET NULL,
  channel      VARCHAR(64) NOT NULL,
  metric_type  VARCHAR(32) NOT NULL,
  value        DOUBLE PRECISION NOT NULL,
  updated_at   TIMESTAMP(3) WITH TIME ZONE NOT NULL
);
```

Индексы:
- `UNIQUE (zone_id, metric_type);`

Laravel в UI обычно берёт данные именно отсюда, а не из `telemetry_samples`.

---

## 6. Таблица `commands`

Хранит команды к узлам.

```sql
CREATE TABLE commands (
  id          VARCHAR(64) PRIMARY KEY,  -- cmd-uuid
  zone_id     BIGINT REFERENCES zones(id) ON DELETE CASCADE,
  node_id     BIGINT REFERENCES device_nodes(id) ON DELETE SET NULL,
  channel     VARCHAR(64) NOT NULL,
  cmd         VARCHAR(64) NOT NULL,     -- run_pump, dose, open_valve...
  params      JSONB,                    -- { "duration_ms": 5000, ... }
  status      VARCHAR(32) NOT NULL,     -- QUEUED / SENT / ACK / ERROR / TIMEOUT
  error       TEXT,
  created_at  TIMESTAMP(0) WITH TIME ZONE,
  updated_at  TIMESTAMP(0) WITH TIME ZONE
);
```

Индексы:
- `INDEX commands_zone_id_index (zone_id);`
- `INDEX commands_status_index (status);`

Python-сервис:
- создаёт записи (или Laravel),
- обновляет `status` при ответе от узла.

---

## 7. Таблицы событий и алертов

### 7.1. Таблица `zone_events`

```sql
CREATE TABLE zone_events (
  id          BIGSERIAL PRIMARY KEY,
  zone_id     BIGINT REFERENCES zones(id) ON DELETE CASCADE,
  type        VARCHAR(64) NOT NULL,    -- PH_CORRECTED, IRRIGATION_STARTED, ...
  details     JSONB,
  created_at  TIMESTAMP(0) WITH TIME ZONE
);
```

Индексы:
- `INDEX zone_events_zone_id_created_at (zone_id, created_at);`

### 7.2. Таблица `alerts`

```sql
CREATE TABLE alerts (
  id          BIGSERIAL PRIMARY KEY,
  zone_id     BIGINT REFERENCES zones(id) ON DELETE CASCADE,
  type        VARCHAR(64) NOT NULL,     -- PH_HIGH, NO_FLOW, LEVEL_LOW...
  details     JSONB,
  status      VARCHAR(32) NOT NULL DEFAULT 'ACTIVE', -- ACTIVE / RESOLVED
  created_at  TIMESTAMP(0) WITH TIME ZONE,
  resolved_at TIMESTAMP(0) WITH TIME ZONE
);
```

Индексы:
- `INDEX alerts_zone_status (zone_id, status);`

---

## 8. Связь с Laravel и Python

**Laravel**:

- создаёт/обновляет:
  - `greenhouses`, `zones`,
  - `recipes`, `growth_phases`, `zone_recipe_instances`,
  - `commands` (при действиях пользователя),
  - помечает `alerts` как `RESOLVED`.
- читает:
  - `telemetry_last`,
  - `telemetry_samples` (для графиков),
  - `zone_events`, `alerts`.

**Python**:

- пишет:
  - `telemetry_samples`,
  - `telemetry_last`,
  - `zone_events`,
  - новые `alerts`,
  - обновляет `commands.status`.
- читает:
  - `zones`, `device_nodes`, `device_channels`,
  - `zone_recipe_instances`, `growth_phases`,
  - `telemetry_last`,
  - `commands` (QUEUED).

ИИ-агент **должен учитывать**, кто владелец каких данных.

---

## 9. Правила расширения схемы для ИИ-агентов

1. **Не ломать существующие таблицы**:
   - не переименовывать таблицы,
   - не удалять поля без крайней необходимости.

2. **Новые поля**:
   - можно добавлять с `NULL` по умолчанию,
   - писать миграцию Laravel вида `add_xxx_to_yyy_table`.

3. **Новые таблицы**:
   - допустимы, если они не ломают существующие связи (например, `energy_usage`, `manual_logs`).

4. **Индексы**:
   - при добавлении новых горячих полей (по которым фильтруем) — предлагать индексы.

5. **Согласованность с Python**:
   - если поле используется Python-сервисом (например, `commands.status`), его тип и смысл **нельзя менять**.

---

## 10. Чек-лист для ИИ перед изменением схемы

1. Таблица уже описана в этом документе? → не ломай, только расширяй.
2. Изменение требуется Laravel, Python или обоим?
3. Нужно ли обновить:
   - Eloquent модель?
   - Python-модель (`db/models.py`)?
4. Не нарушены ли FK?
5. Нужны ли индексы под новые запросы?
6. Не раздуваем ли `telemetry_samples` лишними полями?

---

# Конец файла DATABASE_SCHEMA_V3_AI_GUIDE.md
