# REST_API_V3_REFERENCE.md
# Полный референс REST API для системы V3
# Laravel + Inertia + PostgreSQL + Python Integration

Этот документ содержит **полный референс всех REST‑эндпоинтов**, которые предоставляет Laravel‑backend системы V3.  
Документ предназначен для:
- frontend‑разработчиков (Vue 3 + Inertia),
- Python‑сервиса (взаимодействие с backend),
- ИИ‑агентов,
- интеграций (Telegram‑бот, внешние сервисы).

API полностью совместимо с архитектурой V3.

---

# 1. Общие правила API

## 1.1. Аутентификация: Laravel Sanctum

Все защищённые эндпоинты требуют:

```
Authorization: Bearer {token}
```

Токены могут иметь роли:

- `admin`
- `operator`
- `viewer`
- `automation_bot`

## 1.2. Формат ответов

Все ответы — JSON:

```json
{
  "status": "ok",
  "data": { ... }
}
```

Ошибки:

```json
{
  "status": "error",
  "message": "Invalid request",
  "code": 400
}
```

## 1.3. Рейтлимит

```
Не более 20 запросов / 1 сек
```

---

# 2. API: Zones (Зоны)

### 2.1. GET /api/zones  
Получить список всех зон.

Ответ:
```json
{
  "status": "ok",
  "data": [
    { "id": 1, "name": "Zone A", "status": "online" }
  ]
}
```

---

### 2.2. GET /api/zones/{id}  
Детальная информация по зоне.

Ответ:
```json
{
  "status": "ok",
  "data": {
    "zone": {...},
    "recipe": {...},
    "current_phase": {...},
    "telemetry": {...},
    "alerts": [...],
    "events": [...]
  }
}
```

---

### 2.3. POST /api/zones  
Создать новую зону.

Тело:
```json
{ "name": "Greenhouse 1" }
```

---

### 2.4. PUT /api/zones/{id}  
Обновить данные зоны.

---

### 2.5. DELETE /api/zones/{id}

Удаляет зону и все связанные данные.

---

# 3. API: Devices / Nodes

### 3.1. GET /api/nodes  
Получить список узлов.

---

### 3.2. GET /api/nodes/{id}  
Подробности узла:
- статусы,
- каналы,
- прошивка,
- последняя телеметрия.

---

### 3.3. POST /api/nodes  
Добавить новый узел.

---

### 3.4. PUT /api/nodes/{id}  
Обновить узел.

---

### 3.5. DELETE /api/nodes/{id}

---

# 4. API: Commands (Команды узлам ESP32)

Команды узлам **не отправляются напрямую через API** —  
они записываются в таблицу `commands`, а Python‑сервис публикует их в MQTT.

---

### 4.1. POST /api/commands  
Создать команду.

Пример:
```json
{
  "zone_id": 1,
  "node_id": 5,
  "channel": "pump_nutrient",
  "cmd": "dose",
  "params": { "ml": 3.0 }
}
```

Ответ:
```json
{
  "status": "ok",
  "data": { "command_id": 51 }
}
```

---

### 4.2. GET /api/commands/{id}  
Получить статус команды.

---

# 5. API: Telemetry

### 5.1. GET /api/zones/{id}/telemetry/last  
Получить последние значения.

---

### 5.2. GET /api/zones/{id}/telemetry/history  
История за период.

Параметры:
```
?from=timestamp
&to=timestamp
&metric=PH,EC,TEMP_AIR,...
```

---

# 6. API: Alerts (Тревоги)

### 6.1. GET /api/alerts  
Получить все тревоги (активные + закрытые).

---

### 6.2. GET /api/alerts/active  
Только активные тревоги.

---

### 6.3. POST /api/alerts/{id}/resolve  
Закрыть тревогу.

Ответ:
```json
{ "status": "ok" }
```

---

# 7. API: Events (События)

### 7.1. GET /api/zones/{id}/events  
Последние события зоны.

---

### 7.2. GET /api/events  
Глобальный список всех событий.

Фильтры:
```
?zone_id=
?type=
?from=
?to=
```

---

# 8. API: Recipes (Рецепты)

### 8.1. GET /api/recipes  
Список рецептов.

---

### 8.2. GET /api/recipes/{id}  
Получить рецепт + фазы.

---

### 8.3. POST /api/recipes  
Создать рецепт.

---

### 8.4. POST /api/recipes/{id}/phases  
Добавить фазу.

---

### 8.5. PUT /api/recipes/{id}/phases/{phase_id}  
Обновить фазу.

---

# 9. API: OTA Firmware

### 9.1. GET /api/ota/firmware  
Список прошивок.

---

### 9.2. POST /api/ota/push  
Инициировать OTA.

Тело:
```json
{
  "node_id": 5,
  "version": "1.0.4"
}
```

---

# 10. API: Users

### 10.1. GET /api/users  
Список пользователей.

---

### 10.2. POST /api/users  
Создать пользователя.

---

### 10.3. PUT /api/users/{id}  
Обновить пользователя.

---

### 10.4. DELETE /api/users/{id}

---

# 11. API: Analytics

### 11.1. GET /api/analytics/zone/{id}
Графики за период:
- pH,
- EC,
- температура,
- влажность,
- расход воды,
- дозирование.

---

### 11.2. GET /api/analytics/dashboard  
Глобальная аналитика:
- статус всех зон,
- тревоги за сутки,
- статистика полива,
- энергия освещения.

---

# 12. Правила для ИИ

ИИ может:
- расширять API,
- добавлять новые эндпоинты,
- вводить новые фильтры,
- добавлять агрегированные данные.

ИИ **не может**:
- менять существующие поля в ответах,
- удалять существующие эндпоинты,
- менять поля команды (`cmd`, `params`),
- ломать совместимость фронта.

---

# 13. Чек‑лист перед изменением API

1. Введённый эндпоинт совместим с V3?  
2. Фронтенд способен обработать данные?  
3. Python не пострадает от изменений?  
4. Структуры ответов стабильны?  
5. Добавленный параметр имеет дефолт?  
6. Изменённый эндпоинт документирован?  
7. Логика доступа учтена (roles/permissions)?  

---

# Конец файла REST_API_V3_REFERENCE.md
