# NODE_CHANNELS_REFERENCE_V3.md
# Полный справочник каналов узлов V3 (ESP32)
# Sensors • Actuators • Metrics • MQTT Topics • Commands • Validation

Документ описывает ВСЕ типы каналов, которые поддерживает система V3:
сенсоры, актуаторы, схемы MQTT-топиков, параметры, команды и структуру данных.

---

# 1. Общая структура узла и каналов

Каждый узел ESP32 имеет:

- **node_id** — уникальный ID (из БД)
- **type** — тип узла (ph, ec, climate, irrig, light, multi)
- **channels[]** — список каналов (2–16 каналов)
- **config** — индивидуальная конфигурация в NVS
- **MQTT namespace**:

```
hydro/{gh}/{zone}/{node}/{channel}/{telemetry|command|status}
```

---

# 2. Типы каналов

Всего три группы:

1. **Sensor channels**
2. **Actuator channels**
3. **Meta channels (служебные)**

---

# 3. Sensor Channels

## 3.1. PH_SENSOR

**Назначение:** измерение pH раствора  
**Данные:** `value` (float), `temperature` (опционально)

Пример MQTT telemetry:
```json
{
  "value": 5.87,
  "temp": 23.1,
  "quality": "ok",
  "ts": 1737355112345
}
```

Интервал отправки: **каждые 3–15 сек**

---

## 3.2. EC_SENSOR

**Назначение:** измерение электропроводности (mS/cm)

MQTT пример:
```json
{
  "value": 1.45,
  "temperature": 23.1,
  "compensated": true,
  "ts": 1737355112000
}
```

---

## 3.3. TEMP_AIR_SENSOR

**Назначение:** температура воздуха  
Сенсоры: SHT30, SHT31, BME280, DS18B20

MQTT:
```json
{ "value": 24.3, "ts": 1737355100000 }
```

---

## 3.4. HUMIDITY_SENSOR

```
{ "value": 62.4 }
```

---

## 3.5. TEMP_WATER_SENSOR

```
{ "value": 21.8 }
```

---

## 3.6. WATER_LEVEL_SENSOR

Типы:
- поплавковый
- ультразвуковой

```
{ "value": 0.76 }
```

---

## 3.7. FLOW_SENSOR (расходомер)

```
{ "value": 1.2, "unit": "L/min" }
```

Используется в Irrigation Controller.

---

## 3.8. LIGHT_SENSOR (люксметр)

```
{ "value": 18500 }
```

---

# 4. Actuator Channels

## 4.1. DOSE_PUMP_ACID

```
cmd: dose
params: { "ml": 0.5 }
```

MQTT команда:
```json
{
  "cmd": "dose",
  "params": { "ml": 0.5 },
  "cmd_id": "abc123",
  "ts": 1737355105000,
  "sig": "...hmac..."
}
```

---

## 4.2. DOSE_PUMP_BASE

То же, но для поднятия pH.

---

## 4.3. DOSE_PUMP_NUTRIENT

EC‑контроллер.

---

## 4.4. IRRIGATION_PUMP

Команды:

- `run {sec}`
- `stop`

Пример:
```json
{"cmd":"run","params":{"sec":8}}
```

---

## 4.5. COOLER_FAN

Команды:
```
on/off
set_speed (опционально)
```

---

## 4.6. HEATER

```
{"cmd": "on"}
```

---

## 4.7. LIGHT_RELAY

```
on/off
dim (опционально)
```

---

## 4.8. VALVE

```
open/close
```

---

# 5. Meta Channels

## 5.1. STATUS

ESP32 отправляет:

```json
{
  "uptime": 55321,
  "rssi": -63,
  "heap": 183000,
  "fw": "1.0.5",
  "ts": 1737355000000
}
```

---

## 5.2. COMMAND_RESPONSE

Узел отвечает:

```json
{
  "cmd_id": "abc123",
  "status": "ok",
  "ts": 1737355004000
}
```

или

```json
{
  "cmd_id": "abc123",
  "status": "error",
  "error": "Pump jammed"
}
```

---

## 5.3. OTA_REPORT

После обновления:

```json
{
  "version": "1.0.6",
  "result": "success"
}
```

---

# 6. MQTT Namespace Reference

```
hydro/{gh}/{zone}/{node}/{channel}/telemetry
hydro/{gh}/{zone}/{node}/{channel}/command
hydro/{gh}/{zone}/{node}/{status}
```

Пример:
```
hydro/gh1/zone3/node12/pH/telemetry
```

---

# 7. Структура хранения в PostgreSQL

## 7.1. telemetry_samples
```
metric_type = channel.type
value
raw
ts
```

## 7.2. telemetry_last
```
zone_id + metric_type = PK
```

---

# 8. Laravel model mapping

### sensor channel → TelemetryLast / TelemetrySamples  
### actuator channel → Commands  
### meta channel → Node model

---

# 9. Python Scheduler usage

Scheduler получает:

- список узлов,
- список каналов,
- типы каналов,
- лимиты каналов (из config.json)

И создает:

- команды,
- события,
- алерты.

---

# 10. Правила для ИИ

ИИ может:

- добавлять новые типы каналов,
- улучшать структуры config,
- вводить комбинированные каналы (multi-sensor),
- повышать надёжность команд.

ИИ не может:

- менять MQTT namespace,
- ломать структуру telemetry,
- изменять команды actuator-каналов.

---

# Конец файла NODE_CHANNELS_REFERENCE_V3.md
