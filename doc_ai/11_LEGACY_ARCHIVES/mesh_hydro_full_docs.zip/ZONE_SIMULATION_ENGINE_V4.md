# ZONE_SIMULATION_ENGINE_V4.md
# Полный симуляционный движок зоны V4
# Multi-Model Simulation • Predictive Control • Stress Testing • Rapid Prototyping

Zone Simulation Engine (ZSE) — это продвинутый симуляционный модуль,
который позволяет полностью воспроизвести работу зоны без физического оборудования.

Он является расширением Digital Twin и используется AI, Python Scheduler и UI.

---

# 1. Назначение Simulation Engine

ZSE позволяет:

- моделировать целую зону в реальном времени,
- воспроизводить работу сенсоров pH, EC, климата, воды,
- тестировать рецепты, циклы, поливы, дозировки,
- проверять безопасность команд,
- оценивать производительность оборудования,
- выполнять стресс‑тестирование,
- оптимизировать параметры зоны до применения в реальности.

ZSE работает в режиме:

```
1× real-time
10× accelerated
100× accelerated
```

---

# 2. Модульная архитектура

Компоненты ZSE:

```
ZoneSimulationEngine/
  ├── state/
  ├── models/
  │    ├── ph_model
  │    ├── ec_model
  │    ├── climate_model
  │    ├── water_model
  │    ├── growth_model
  ├── controllers/
  ├── sim_runner/
  └── api/
```

---

# 3. Симулируемые элементы

### Сенсоры:
- pH
- EC
- температура воздуха
- влажность воздуха
- температура воды
- уровень воды
- расход (flow)
- освещённость

### Актуаторы:
- дозирующие насосы pH/EC
- насосы полива
- клапаны
- вентиляторы
- обогреватели
- увлажнители/осушители
- освещение

---

# 4. Симуляция pH

Уравнение:

```
pH_new = pH_old + acid_effect + base_effect + drift − plant_absorption
```

Twin-derived parameters:

- acid_effect = dose_acid_ml × acid_factor
- base_effect = dose_base_ml × base_factor
- drift зависит от времени

Поддерживает:
- калибровку
- изменение объёма бака
- температуру

---

# 5. Симуляция EC

```
EC_new = EC_old + nutrient_effect − dilution − absorption
```

Факторы:

- nutrient_effect зависит от ml дозы
- dilution зависит от испарения и долива
- absorption зависит от фазы растения

---

# 6. Симуляция климата

Температура:

```
temp_new = temp_old + heater − cooler + light_heat + external_influence
```

Влажность:

```
rh_new = rh_old + transpiration − ventilation − dehumidification
```

Свет:

- PAR зависимость от светильников
- нагрев от света

---

# 7. Симуляция воды

Система моделирует:

- испарение
- уровень воды
- расход при поливах
- работу насосов
- заполнение/слив
- mixing cycle

Формула уровня:

```
water_level = water_level_old − evap + refill + irrigation_add − drain
```

---

# 8. Симуляция роста растения

Модель роста оценивает:

- биомассу,
- высоту,
- LAI (leaf area index),
- скорость потребления воды,
- потребление EC,
- потребление pH.

```
growth_rate = f(light, temperature, VPD, nutrition)
```

---

# 9. Контроллеры

ZSE воспроизводит работу:

- pH Controller
- EC Controller
- Climate Controller
- Irrigation Controller
- Light Controller

Контроллеры работают в симуляции так же, как в реальности.

---

# 10. Simulation Runner

Центральный цикл:

```
loop:
    apply_actuators()
    simulate_models()
    update_state()
    log()
```

Поддерживает:

- real-time
- accelerated time
- paused mode
- step-by-step mode

---

# 11. Типы симуляций

## 11.1. Full‑zone simulation (24h, 7d, 30d)

Вывод:

- график pH/EC
- график климата
- схема воды
- расход энергии
- выход растений (yield score)

## 11.2. Cycle simulation

Симуляция одного полива/дозы.

## 11.3. Recipe simulation

```
simulate(recipe_id, zone_profile)
```

Вывод:

- оптимальное EC
- прогноз pH drift
- прогноз урожайности
- water usage
- energy usage

## 11.4. Stress testing

Варианты:

- отключение насоса
- перегрев зоны
- низкий уровень воды
- уменьшение расхода
- деградация сенсора
- неверная калибровка

Результат:

```
RISK_SCORE
FAULT_PROBABILITY
SAFE_COMMANDS_ONLY
```

---

# 12. Simulation Safety Layer

Перед отправкой команд в реальную систему:

```
simulate(command, horizon=10 minutes)
```

Если COULD_BE_DANGEROUS → блокировка.

Типы опасностей:

- pH уходит за пределы
- EC выходит за норму
- перегрев
- слишком низкий уровень воды
- превышение нагрузки
- чрезмерная дозировка

---

# 13. API Simulation Engine

### Laravel → ZSE

```
POST /api/sim/run
POST /api/sim/recipe
POST /api/sim/cycle
POST /api/sim/check
```

### Ответ:

```
{
  "safe": true,
  "state_after": {...},
  "recommendations": {...},
  "graphs": {...}
}
```

---

# 14. UI интеграция

UI отображает:

- интерактивные графики,
- симуляцию текущей зоны,
- прогнозы,
- результаты стресс‑тестов,
- рекомендации AI,
- yield score,
- energy score,
- оптимальные рецепты.

---

# 15. Правила для ИИ

ИИ может:

- улучшать модели симуляции,
- добавлять новые сценарии,
- оптимизировать growth models,
- улучшать detection отклонений.

ИИ НЕ может:

- отключать safety check,
- игнорировать отклонения,
- занижать риск,
- разрешать опасные команды.

---

# 16. Чек‑лист перед релизом

1. Модели согласованы с Digital Twin?  
2. Реальные данные совпадают с симуляцией?  
3. Safety работает корректно?  
4. UI отображает графики?  
5. API отвечает правильно?  
6. Стресс‑тесты дают корректные предупреждения?  
7. Время симуляции достаточное?  
8. Нет ошибок расчёта pH/EC?  

---

# Конец файла ZONE_SIMULATION_ENGINE_V4.md
