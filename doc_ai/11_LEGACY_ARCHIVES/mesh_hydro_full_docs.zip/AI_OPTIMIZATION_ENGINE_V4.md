# AI_OPTIMIZATION_ENGINE_V4.md
# Полная архитектура AI-движка оптимизации V4
# Machine Learning • Predictive Models • Adaptive Control • Digital Twin • Autonomous Hydroponics

Документ описывает **следующее поколение умных алгоритмов**, которое становится центральным компонентом системы V4.

AI‑движок выполняет:
- прогнозирование параметров (pH, EC, климат, влажность),
- адаптивное дозирование,
- умный полив,
- автотюнинг рецептов,
- оптимизацию расхода энергии, воды и удобрений,
- построение цифрового двойника (Digital Twin),
- автоматическую диагностику системы.

---

# 1. Общая архитектура AI-движка V4

Общий pipeline:

```
Telemetry → Feature Extraction → ML Models → Decisions → Controllers → Commands
```

AI работает как отдельный сервис:

```
ai_service/
  ├── models/
  ├── pipelines/
  ├── inference/
  ├── training/
  ├── twins/
  └── api/
```

Компоненты:

1. **AI Inference Engine**
2. **Training Engine**
3. **Optimization Engine**
4. **Digital Twin Engine**
5. **Anomaly Detection Engine**
6. **Recommendation Engine**
7. **AI API Layer**

---

# 2. Источники данных

AI получает данные из:

- telemetry_last (актуальные значения)
- telemetry_samples (история)
- recipe_phases (цели)
- commands (история дозирования)
- alerts (аномалии)
- climate logs
- user adjustments
- water flow telemetry
- energy usage (если подключено)

---

# 3. Feature Extraction (создание признаков)

Основные признаки:

### 3.1. pH features
- текущее pH
- скорость изменения pH (dpH/dt)
- дельта pH к цели
- объем последних дозировок
- температура воды

### 3.2. EC features
- текущее EC
- скорость изменения EC
- расход питательного насоса
- объем раствора в системе

### 3.3. Climate features
- температура и влажность
- VPD
- освещённость
- время суток
- активность климат-контроля

### 3.4. Irrigation features
- история поливов
- расход
- интервал испарения
- рост (по фазе)

### 3.5. System features
- uptime узлов
- стабильность сенсоров
- корреляции pH ↔ EC ↔ температура

---

# 4. Модели AI

## 4.1. pH Prediction Model

ML-модель для прогнозирования поведения pH:

```
pH_future(t) = model(pH_current, dose_history, temperature, EC, time)
```

Использование:
- вычисление минимальной дозы
- предотвращение “перекисления”

Тип модели:
- LightGBM или Neural Network

---

## 4.2. EC Prediction Model

```
EC_future = EC + predicted_change
```

Применение:
- адаптивная дозировка
- корректировка для разных растений

---

## 4.3. Climate Prediction Model

Прогноз температуры и влажности:

```
temp(t+30m) = f(climate_history, light_schedule, outdoor_weather)
hum(t+30m) = f(...)
```

---

## 4.4. Irrigation Optimization Model

Модель испарения воды и потребностей растения:

```
irrigation_interval = ML.predict(evaporation_rate, growth_phase)
```

---

## 4.5. Anomaly Detection

Методы:
- Isolation Forest
- Autoencoder
- Statistical deviation

Обнаруживает:
- сломанные сенсоры
- нестабильные насосы
- плохие сигналы
- несоответствие модели Digital Twin

---

# 5. Digital Twin (цифровой двойник зоны)

Цифровой двойник имитирует:

- динамику pH
- динамику EC
- климат
- поглощение питательных веществ
- водный цикл
- фото-периодизм

Используется для:
- тестирования решений AI перед отправкой команд
- прогнозирования последствий
- авто-настройки рецептов

---

# 6. Optimization Engine

Цель: минимизировать отклонения от целевых параметров.

Формула:

```
cost = w1*(|pH - target_pH|) +
       w2*(|EC - target_EC|) +
       w3*(|temp - target_temp|) +
       w4*(|humidity - target_humidity|)
```

Оптимизатор:
- Gradient-based
- Grid search
- Bayesian Optimization

Результаты:
- новая доза
- новый интервал полива
- коррекция света
- коррекция климата

---

# 7. Recommendation Engine

AI рекомендует пользователю:

- улучшить циркуляцию
- поменять фильтр
- добавить воды
- сменить раствор
- обновить рецепт
- оптимизировать интервал полива
- изменить световой график

---

# 8. AI API Layer

### AI Service → Laravel API

```
POST /api/ai/recommendation
POST /api/ai/optimized_targets
POST /api/ai/predictions
```

### Laravel → AI Service

```
/ai/zone/{id}/state
/ai/zone/{id}/history
```

---

# 9. AI Control Levels

В V4 вводится Multi-Level AI:

| Уровень | Описание |
|---------|----------|
| L0 | Без AI (ручной режим) |
| L1 | AI Monitoring – прогнозы, алерты |
| L2 | AI Recommendations – предлагает решения |
| L3 | AI Assisted Control – делает корректировки с разрешением |
| L4 | Fully Autonomous – сам управляет зоной |

---

# 10. Безопасность AI Layer

AI НЕ может:

- отправлять команды напрямую узлам,
- менять рецепты без разрешения,
- игнорировать alerts,
- работать без цифрового двойника.

Все команды проходят через Command Dispatcher.

---

# 11. Интеграция с UI

UI показывает:

- предсказания pH/EC
- прогноз климата
- графики AI vs actual
- рекомендации
- уровень автономности
- симуляции Digital Twin

---

# 12. Правила для ИИ

ИИ может:

- создавать новые модели,
- улучшать функции стоимости,
- внедрять RL‑алгоритмы,
- расширять Digital Twin,
- оптимизировать контроллеры.

ИИ НЕ может:

- подавлять тревоги,
- выключать защитные механизмы,
- изменять MQTT или команды,
- ломать формат telemetry.

---

# 13. Чек-лист AI Layer перед релизом

1. Модели стабильны?  
2. Digital Twin проходит тесты?  
3. Отклонения ≤ 10%?  
4. Команды безопасны?  
5. L0–L4 работают корректно?  
6. Laravel UI отображает рекомендации?  
7. AI API протестированы?  

---

# Конец файла AI_OPTIMIZATION_ENGINE_V4.md
