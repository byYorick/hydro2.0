# FIRMWARE_STRUCTURE_V3.md
# Полная структура прошивки V3 для ESP32
# Архитектура • Модули • Задачи • MQTT • OTA • NVS • Драйверы • Контроллеры

Документ описывает полную архитектуру прошивки V3 для ESP32 / ESP32‑S3,  
которая используется в гидропонной системе.

Он предназначен для:
- разработчиков прошивки,
- backend-инженеров,
- Python-сервиса,
- ИИ-агентов.

---

# 1. Общая архитектура прошивки

Прошивка построена по модульному принципу:

```
main/
  ├── app_main.c
  ├── config/
  ├── drivers/
  ├── sensors/
  ├── actuators/
  ├── mqtt/
  ├── ota/
  ├── nvs/
  ├── scheduler/
  └── utils/
```

Основные подсистемы:

1. **MQTT Engine** — обмен данными
2. **Telemetry Engine** — опрос сенсоров
3. **Actuator Engine** — насосы, реле, вентиляторы
4. **Command Engine** — выполнение команд
5. **OTA Engine** — обновления прошивки
6. **NVS Storage** — конфигурация узла
7. **Sensors Layer** — pH, EC, температура и др.
8. **Channels Mapping** — привязка каналов
9. **Scheduler (RTOS tasks)**

---

# 2. Основные задачи FreeRTOS

## 2.1. mqtt_task
- подписка на топики:
  - `.../command`
  - `.../config`
- отправка telemetry
- отправка status
- отправка responses

Период: каждые 50–200 мс.

---

## 2.2. sensor_task
Опрос всех сенсоров:

| Сенсор | Интервал |
|--------|----------|
| pH | 2–5 сек |
| EC | 2–5 сек |
| Температура воздуха | 2 сек |
| Влажность | 2 сек |
| Уровень воды | 10 сек |
| Свет | 10 сек |

---

## 2.3. actuator_task
Выполняет команды управления:

- дозирование
- запуск насосов
- переключение клапанов
- включение света

Поддерживает безопасные таймеры:

```
auto_stop_after X секунд
```

---

## 2.4. status_task
Отправляет:

```json
{
  "uptime": 55321,
  "heap": 182332,
  "rssi": -63,
  "fw": "1.0.3"
}
```

Интервал: каждые 30 сек.

---

## 2.5. ota_task
Выполняет обновления, если получена команда OTA.

---

# 3. Инициализация

```
wifi_init()
mqtt_init()
nvs_init()
load_channels_config()
start_rtos_tasks()
```

Загрузка конфигурации:

```
node_secret
node_id
gh_id
zone_id
channels[]
calibration_data
```

---

# 4. Структура NVS

### nvs namespaces:

- `node_info`
- `channels`
- `calib`
- `network`

### nvs keys:

| Key | Описание |
|------|----------|
| node_id | ID узла |
| node_secret | секрет подписи команд |
| channel_1 | конфигурация канала |
| ph_offset | калибровка pH |
| ec_k | k-фактор EC |
| wifi_ssid | WiFi |
| wifi_pass | пароль |

---

# 5. MQTT Engine

MQTT namespace:

```
hydro/{gh}/{zone}/{node}/{channel}/telemetry
hydro/{gh}/{zone}/{node}/{channel}/command
hydro/{gh}/{zone}/{node}/status
hydro/{gh}/{zone}/{node}/ota
hydro/{gh}/{zone}/{node}/config
hydro/{gh}/{zone}/{node}/{channel}/command_response
```

Подписки:
- `.../command`
- `.../config`
- `.../ota`

Публикации:
- telemetry
- status
- responses

---

# 6. Channel Mapping

Каждый канал хранится в NVS:

```
channel_id: {
  "type": "PH_SENSOR",
  "pin": 32,
  "metric": "PH"
}
```

Поддерживаемые типы:

- PH_SENSOR
- EC_SENSOR
- TEMP_AIR_SENSOR
- HUM_SENSOR
- WATER_LEVEL_SENSOR
- FLOW_SENSOR
- DOSE_PUMP_ACID
- DOSE_PUMP_BASE
- NUTRIENT_PUMP
- IRRIGATION_PUMP
- LIGHT_RELAY
- VALVE
- FAN
- HEATER

---

# 7. Sensor Drivers

## 7.1. PH_SENSOR
ADC + фильтр + компенсация температуры.

```
raw → voltage → pH
```

## 7.2. EC_SENSOR
I2C/Trema или аналоговый.

## 7.3. TEMP_AIR_SENSOR
Поддерживает:
- SHT3x
- DS18B20
- BME280

## 7.4. HUM_SENSOR
SHT3x, BME280.

## 7.5. WATER_LEVEL_SENSOR
Аналоговый или цифровой.

## 7.6. FLOW_SENSOR
Прерывания GPIO → импульсы → L/min.

---

# 8. Actuator Drivers

## 8.1. L9110 Pump Driver
```
run(sec)
stop()
auto_cutoff
```

## 8.2. Relay Driver

## 8.3. PWM Driver

## 8.4. Valve Driver

---

# 9. Command Engine

Команда приходит:

```json
{
  "cmd": "dose",
  "params": {"ml": 1.5},
  "cmd_id": "abc123",
  "ts": 1737355112,
  "sig": "HMAC..."
}
```

Проверка:

1. подпись  
2. timestamp (±10 сек)  
3. допустимые параметры  
4. лимит времени  

Ответ:

```
ok / error
```

---

# 10. OTA Engine

Процедура:

1. получить команду OTA:
```
{"version":"1.0.5","url":"https://...","sha256":"..."}
```
2. скачать файл
3. проверить sha256
4. записать в OTA partition
5. перезагрузка
6. отправить OTA_REPORT

---

# 11. Безопасность

- командная подпись HMAC
- secure NVS
- защита OTA
- проверка команд
- фильтрация входящих сообщений
- защита от перегрева насосов
- watchdog

---

# 12. Watchdog System

Включает:

- системный watchdog (1–3 сек)
- task watchdog (отдельный для sensor_task)

Если зависание — перезагрузка узла.

---

# 13. Логи и диагностика

DEBUG режим отправляет:

```
/debug/log
```

пример:
```
"EC_SENSOR: raw=1432, ec=1.45"
```

---

# 14. Структура исходников (пример)

```
main/
  app_main.c
  config/node_config.c
  mqtt/mqtt_client.c
  ota/ota_manager.c
  sensors/ph_sensor.c
  sensors/ec_sensor.c
  sensors/temp_air_sensor.c
  actuators/pump_driver.c
  actuators/relay_driver.c
  command/command_parser.c
  command/command_executor.c
  scheduler/tasks.c
  utils/json_builder.c
```

---

# 15. Правила для ИИ

ИИ может:

- улучшать фильтры сенсоров,
- оптимизировать задачи FreeRTOS,
- добавлять новые типы каналов,
- улучшать драйверы,
- оптимизировать MQTT.

ИИ НЕ может:

- отключать подпись команд,
- менять MQTT namespace,
- нарушать совместимость с backend,
- отключать watchdog.

---

# 16. Чек-лист перед релизом прошивки

1. OTA работает?  
2. Сенсоры корректны?  
3. HMAC-подпись проверяется?  
4. Watchdog включён?  
5. Команды проверяются?  
6. Логи включаемы?  
7. MQTT reconnect стабилен?  
8. FreeRTOS задачи не перегружены?  
9. NVS структура корректна?  
10. Ресурсы памяти в пределах нормы?

---

# Конец файла FIRMWARE_STRUCTURE_V3.md
