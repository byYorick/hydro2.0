# FULL_UI_UX_DESIGN_V4.md
# Полный UI/UX дизайн-гайд для системы V4
# Modern SPA • Inertia.js • Vue 3 • TailwindCSS • Responsive • AI‑Augmented Interface

Документ описывает полный дизайн-гайд пользовательского интерфейса V4.
Он определяет структуру, принципы, навигацию, дизайн‑паттерны, компоненты и логику UI.

---

# 1. Общие принципы UI/UX V4

UI должен быть:

- **быстрым** (SPA на Vue 3 + Inertia)
- **минималистичным**
- **информативным**
- **адаптивным**
- **AI‑дополненным**
- **интерактивным**
- **многозонным**
- **надежным при ошибках**

Визуальный стиль:

- Semi‑Flat Design
- Tailwind 3.x
- Анимации Framer-Motion-like (VueUse Motion)
- Иконки: Heroicons / Lucide
- Цветовая палитра: синий‑бирюза‑серый

---

# 2. Основные разделы интерфейса

UI состоит из разделов:

```
Dashboard
Zones
Nodes
Recipes
AI Center
Simulation
Energy
Events & Alerts
Logs & Telemetry
Settings
Users & Roles
Developer Tools
```

---

# 3. Структура Dashboard (главная панель)

Элементы:

- Summary по зонам
- Карта теплицы
- Общие алерты
- Производительность / КПД
- Энергетика (мощность / стоимость)
- Узлы онлайн / оффлайн
- AI рекомендации
- Быстрые действия:

  - Запустить полив
  - Запустить смешивание
  - Перейти к зоне

Карточки:

- Zone Snapshot Card  
- Node Snapshot Card  
- Telemetry Summary Card  
- Alert Card  
- Energy Card  

---

# 4. Страница зоны (Zone View)

Структура:

```
Header (название зоны, статус, фаза)
Tabs:
   Telemetry
   Controllers
   Graphs
   Irrigation
   Climate
   EC/pH
   AI Panel
   Simulation
   Events
   Logs
```

### 4.1. Telemetry Tab
- последние значения pH, EC, температуры, влажности, уровня
- индикаторы стабильности
- кнопка “Симулировать день”

### 4.2. Controllers Tab
Компоненты:

- pH Controller Widget
- EC Controller Widget
- Irrigation Controller Widget
- Climate Controller Panel
- Light Controller Panel
- AI Target Adjustments Panel

Каждый контроллер имеет:

- текущие цели,
- фактические значения,
- кнопки команд,
- лог состояния.

### 4.3. Graphs
Графики (ECharts):

- pH / EC / Температура / Влажность
- VPD
- Flow
- Mixing
- Energy Usage
- AI Predictions

---

# 5. Страница узла (Node View)

Показывает:

- статус узла
- RSSI & Wi‑Fi качество
- прошивку
- uptime
- диагностику (heap, temp)
- привязку каналов
- статус актуаторов
- статистику команд
- Raw Telemetry View

Дополнительно:

- OTA обновление
- Перезапуск узла
- Скан Wi‑Fi
- Диагностические отчеты

---

# 6. Страница рецептов (Recipes)

Список:

- пресеты
- рецепты
- фазы
- AI‑сгенерированные рецепты

Редактор рецептов:

- Drag‑and‑drop фазы
- Настройка pH/EC/климата/света/полива
- Preview в Digital Twin
- Кнопка “Оптимизировать через AI”

---

# 7. AI Center

Раздел:

- AI Recommendations Stream
- Анализ дрейфа pH/EC
- Прогноз климата
- Рекомендации по свету и энергии
- AI Chat для взаимодействия с системой
- Simulation Assistant
- Recipe Optimizer
- Anomaly Detector Feed
- AI‑generated insights

---

# 8. Simulation Engine UI

Функции:

- запустить симуляцию фазы
- запустить симуляцию рецепта
- стресс‑тест зоны
- сравнение “реальность vs симуляция”
- графики Twin
- прогноз ресурсоёмкости

---

# 9. Energy Dashboard

Содержит:

- live мощность
- прогноз нагрузки
- график стоимости
- работа energy контроллера
- периоды пиковой нагрузки
- AI рекомендации по экономии

Компоненты:

- Energy Gauge
- Power Timeline
- Cost Forecast
- Load Optimizer Panel

---

# 10. Events & Alerts

Страница:

- список всех событий
- фильтр по зонам/типам
- критические алерты
- игнорируемые алерты
- история алармов
- панель действий (acknowledge, resolve)

---

# 11. Logs & Telemetry

UI показывает:

- системные логи
- логи узлов
- логи команд
- телеметрию в «сырых» данных
- экспорт CSV/JSON
- фильтрация по событиям

---

# 12. User Management

Функции:

- пользователи
- роли
- permissions
- токены
- API‑ключи
- аудит действий

UI отображает:

- лог входов
- действия пользователей
- чувствительные операции

---

# 13. Settings

Раздел:

- MQTT настройки
- AI настройки
- симулятор
- параметры зон
- параметры безопасности
- управление брокерами
- Device Registry

---

# 14. Design-system (Tailwind + Vue Components)

### 14.1. Tailwind tokens

```
--color-primary: #0ea5e9;
--color-secondary: #14b8a6;
--color-neutral: #334155;
--radius: 0.5rem;
--shadow: 0 4px 15px rgba(0,0,0,0.15);
```

### 14.2. Базовые компоненты

- Button
- Card
- Input/Textarea
- Select
- Switch
- Tabs
- Table
- Badge
- Toast
- Dialog
- Drawer
- Tooltip

### 14.3. Специализированные компоненты

- TelemetryTile
- ControllerPanel
- ZoneHeader
- NodeHealthBadge
- GraphCard
- SimulationRunnerPanel
- AIRecommendationCard
- AlertBanner
- EnergyGauge

---

# 15. Адаптивность

Макеты:

- Desktop (≥1280)
- Tablet (768–1279)
- Mobile (≤767)

Логика:

- графики — stack → swipe mode
- панели — collapsible
- меню — drawer
- плитки — grid → list

---

# 16. UX безопасности

UI блокирует опасные действия:

- кнопки отключаются при active safety
- предупреждение при опасных командах
- подтверждение при критических операциях
- уведомления о системных ошибках

---

# 17. Взаимодействие с AI

UI выполняет:

- контекстные подсказки
- AI‑режим обучения
- AI‑предпросмотр действий
- автозаполнение форм
- адаптивные рекомендации

---

# 18. Чек‑лист UI/UX перед релизом

1. Все панели работают?  
2. Графики отображают данные?  
3. Контроллеры управляются корректно?  
4. UI реагирует на алерты?  
5. Мобильная версия полноценна?  
6. AI панель работает?  
7. Симуляции отображаются корректно?  
8. Energy Dashboard работает?  
9. Logs/Telemetry доступна?  
10. Роли соблюдаются?  

---

# Конец файла FULL_UI_UX_DESIGN_V4.md
