# DIGITAL_TWIN_ENGINE_V4.md
# Полный цифровой двойник зоны (Digital Twin) в архитектуре V4
# Simulation • Predictive Modeling • Virtual Sensors • Scenario Testing • Safety Sandbox

Документ описывает цифровой двойник (Digital Twin) зоны в системе V4.
Это полностью математическая модель, которая имитирует:
- pH динамику
- EC динамику
- температуру
- влажность
- свет
- испарение
- рост растения
- водный баланс

Digital Twin используется чтобы:
- тестировать команды перед отправкой на реальные узлы,
- предсказывать реакцию системы,
- предотвращать опасные состояния,
- оптимизировать рецепты и полив,
- обучать AI‑модели.

---

# 1. Общая архитектура Digital Twin

Twin состоит из 5 крупных подсистем:

```
pH Model
EC Model
Climate Model
Irrigation/Water Model
Plant Growth Model
```

И сервисов взаимодействия:

```
Twin API
Twin Simulation Engine
Twin Sync Engine (с реальными данными)
Twin Safety Validator
Twin Scenario Runner
```

---

# 2. Источники данных для Twin

Twin получает данные:

- telemetry_last (сенсоры)
- telemetry_samples (история)
- recipes (цели и фазы)
- events (реакция системы)
- commands history (дозирование, полив)
- external weather (опционально)
- plant growth presets

Twin обновляет состояние каждые 1–10 сек.

---

# 3. Модель pH

Уравнение:

```
pH(t+1) = pH(t)
          + f(dose_acid, dose_base)
          + f(temperature)
          + natural_drift
          - absorption_by_plants
```

Где:

- `dose_acid` снижает pH,
- `dose_base` поднимает pH,
- `natural_drift` моделирует дрейф pH раствора.

Twin учитывает:
- объём баков,
- концентрацию раствора,
- предыдущие дозировки.

---

# 4. Модель EC (электропроводности)

Математическая модель:

```
EC(t+1) = EC(t)
         + nutrient_addition
         - dilution (evaporation vs refill)
         - plant_absorption
```

Twin учитывает:
- расход насоса EC,
- объём бака,
- испарение.

---

# 5. Модель климата

## 5.1 Температура

```
temp(t+1) = temp(t)
            + heating_effect
            - cooling_effect
            + light_heating
            + outdoor_influence
```

## 5.2 Влажность

```
humidity(t+1) = humidity(t)
                + plant_transpiration
                - ventilation
                - dehumidifier_effect
```

## 5.3 Свет

Twin моделирует:
- PAR intensity
- фотопериодизм
- нагрев от освещения

---

# 6. Модель испарения и полива

Уравнение испарения:

```
evap_rate = f(temp, humidity, airflow, plant_stage)
```

Twin предсказывает:
- сколько воды потеряется за сутки,
- когда нужен полив,
- оптимальный объём.

---

# 7. Модель роста растения

Рост по фазам:

```
height(t+1) = height(t) + growth_rate * light_factor * nutrient_factor * climate_factor
```

Twin хранит:

- biomass,
- leaf area index,
- nutrient uptake rate,
- transpiration rate.

Эти параметры используются для оптимизации EC/pH.

---

# 8. Twin Safety Validator

Перед отправкой команды система выполняет симуляцию:

```
simulate(command, horizon=5 minutes)
```

Twin проверяет:
- не уйдёт ли pH за пределы,
- не станет ли EC слишком высоким,
- не включит ли насос при низком уровне,
- не приведёт ли команда к перегреву.

Если опасно → команда блокируется:

```
command_rejected: reason="unsafe_prediction"
```

---

# 9. Twin Scenario Runner

Twin может симулировать:

- сутки работы,
- неделю,
- влияние изменения рецепта,
- разные уровни света,
- разные температуры,
- влияние поливов,
- стрессовые ситуации.

Пример сценария:

```
simulate_recipe(recipe_id)
```

Twin возвращает прогноз:

```
{
  "ideal_EC": 1.42,
  "expected_pH_drift": 0.3,
  "water_usage": 12.4,
  "yield_score": 0.91
}
```

---

# 10. Twin Sync Engine

Twin синхронизируется с реальной зоной:

- обновляет состояние
- корректирует параметры моделей
- адаптирует кривые роста
- подстраивает evap-rate

Если Twin обнаруживает расхождение:

```
ANOMALY_DETECTED
```

Twin передаёт данные в AI + Alerts.

---

# 11. Twin API

Laravel и Python могут вызывать:

```
POST /ai/twin/update
POST /ai/twin/predict
POST /ai/twin/simulate
POST /ai/twin/safety_check
```

Формат ответа:

```
{
  "safe": true,
  "predicted_state": {...},
  "recommended_adjustments": {...}
}
```

---

# 12. Twin и AI

AI использует Twin:

- для обучения моделей,
- для тестирования стратегий,
- для предсказаний,
- для оптимизации рецептов,
- как sandbox перед командой.

AI уровни L2–L4 требуют Twin.

---

# 13. Twin в UI

Панель отображает:

- будущие pH / EC графики
- виртуальную воду в баке
- прогноз климата
- predicted vs actual
- симуляции рецептов
- риск ошибок

---

# 14. Правила для ИИ

ИИ может:

- улучшать модели Twin,
- подключать внешние данные,
- расширять plant growth model,
- улучшать safety logic.

ИИ НЕ может:

- включать команды без валидации,
- отключать safety layer,
- снижать точность моделей.

---

# 15. Чек-лист Twin перед релизом

1. pH модель корректна?  
2. EC модель воспроизводит производственную систему?  
3. Климат моделируется?  
4. Испарение правильно считается?  
5. Twin согласован с реальными данными?  
6. Safety Validator работает?  
7. UI графики отображаются?  
8. API доступен?  

---

# Конец файла DIGITAL_TWIN_ENGINE_V4.md
