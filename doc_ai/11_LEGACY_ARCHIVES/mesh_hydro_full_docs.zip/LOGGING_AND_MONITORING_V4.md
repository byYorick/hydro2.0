# LOGGING_AND_MONITORING_V4.md
# Полная система логирования и мониторинга V4
# Observability • Metrics • Tracing • Alerting • Log Pipelines • Health Checks

Документ описывает всю систему наблюдаемости (Observability) в архитектуре V4.
Она объединяет логирование, метрики, алерты, мониторинг узлов, зону и кластер сервисов.

---

# 1. Компоненты Observability V4

Система состоит из 6 основных блоков:

```
Log Engine
Metrics Engine
Event Engine
Health Monitoring
Alerting Engine
Tracing Engine
```

---

# 2. Log Engine (централизованное логирование)

Все сервисы пишут логи в единый поток:

Источник логов:
- ESP32 (через MQTT topic `/debug/log`)
- Python Scheduler
- AI Service
- Laravel Backend
- Simulation Engine
- Database Events
- Systemd logs контейнеров

Структура логов:

```json
{
  "service": "python_scheduler",
  "zone_id": 2,
  "node_id": 11,
  "event": "COMMAND_SENT",
  "details": {...},
  "ts": 1737358112000,
  "level": "info"
}
```

Типы уровней:
- debug
- info
- warning
- error
- critical

Хранение:
- short-term hot logs в PostgreSQL (7–30 дней)
- long-term cold logs в файловом архиве или S3‑совместимом хранилище

---

# 3. Metrics Engine (система метрик)

Все данные публикуются в:

```
metrics/
   system/
   python/
   laravel/
   ai/
   nodes/
   zones/
```

Метрики включают:

### 3.1. System Metrics
- CPU %, RAM %
- load average
- дисковое пространство
- network IO

### 3.2. Python Scheduler Metrics
- command_queue_depth
- avg_command_latency
- telemetry_rate
- errors_per_minute

### 3.3. Laravel Metrics
- API response time
- DB query count
- web requests rate

### 3.4. Node Metrics
- uptime
- RSSI
- heap usage
- sensor stability metrics

### 3.5. Zone Metrics
- avg pH deviation
- avg EC deviation
- avg VPD error
- irrigation frequency
- energy use

---

# 4. Tracing Engine

Трассировка событий и команд:

```
command → validation → dispatch → mqtt_send → mqtt_ack → backend_update
```

Каждая команда получает trace_id.

Trace пример:

```json
{
  "trace_id": "cmd-123-x8",
  "stages": [
    {"stage": "validated_laravel", "ts": ...},
    {"stage": "sent_python", "ts": ...},
    {"stage": "mqtt_published", "ts": ...},
    {"stage": "esp_ack", "ts": ...},
    {"stage": "backend_saved", "ts": ...}
  ]
}
```

---

# 5. Event Engine

События хранятся в таблице:

```
zone_events
```

Типы:

- SENSOR_OUT_OF_RANGE
- IRRIGATION_CYCLE
- DOSING
- COMMAND_SENT
- COMMAND_TIMEOUT
- NODE_OFFLINE
- ALERT_ACTIVE
- ENERGY_PEAK
- AI_RECOMMENDATION
- SIMULATION_RESULT
- OTA_COMPLETED

---

# 6. Alerting Engine

Алерты делятся на три уровня:

| Level | Description |
|--------|-------------|
| info | несерьёзные отклонения |
| warning | требуется внимание |
| critical | опасная ситуация |

Параметры:

- auto-resolve
- requires_manual_resolve
- triggers safety

Пример алерта:

```json
{
  "type": "PH_HIGH",
  "zone_id": 2,
  "value": 7.1,
  "target": 6.0,
  "severity": "warning"
}
```

---

# 7. Monitoring Dashboard (UI)

Панели:

### 7.1. Node Health
- online/offline
- RSSI
- heap
- uptime
- restart counter

### 7.2. Zone Overview
- pH/EC deviation graph
- climate deviations
- irrigation frequency
- energy consumption

### 7.3. System Dashboard
- CPU/RAM
- Docker containers
- Python processes
- Queue depth
- Error rate

### 7.4. AI Dashboard
- prediction accuracy
- anomaly detections
- recommended vs executed commands

### 7.5. Simulation Dashboard
- simulation vs real data
- scenario results

---

# 8. Node Health Monitoring

На основе:
- status telemetry
- missed pings
- signal strength
- memory health
- sensor noise level
- error counters

Узел считается:
- **online** — обновление ≤ 60 сек
- **unstable** — 60–300 сек
- **offline** — более 300 сек

---

# 9. Zone Health Monitoring

Система анализирует:

- отклонения от рецепта
- колебания pH/EC
- климатические аномалии
- недостаточный/избыточный полив
- высокий расход энергии

Зона получает рейтинг:

```
health_score = 0–100
```

---

# 10. Log Pipelines

Три уровня хранения:

### hot logs
- последние 7–30 дней
- в PostgreSQL

### warm logs
- архивы в zip/tar
- локальное хранилище

### cold logs
- S3/Backblaze/Wasabi
- хранение 1+ год

---

# 11. API Monitoring

Laravel предоставляет:

```
GET /api/monitoring/system
GET /api/monitoring/nodes
GET /api/monitoring/zones
GET /api/monitoring/errors
GET /api/monitoring/events
```

---

# 12. Anomaly Detection Integration

AI анализирует:
- резкие скачки телеметрии
- повторяющиеся ошибки
- низкое качество сигналов
- расход vs прогноз
- климатические отклонения

В случае проблемы создаётся:

```
ANOMALY_DETECTED
```

---

# 13. Safety Monitoring

Safety triggers:
- остановка всех насосов при low water
- блокировка дозирования при NO_FLOW
- отключение климат-контроля при плохом сенсоре
- запрет команд при NODE_OFFLINE

---

# 14. Правила для ИИ

ИИ может:
- классифицировать аномалии,
- улучшать scoring,
- оптимизировать логику алертов.

ИИ НЕ может:
- отключать safety уровни,
- менять severity алертов,
- игнорировать критические отклонения.

---

# 15. Чек-лист перед релизом Monitoring

1. Все логи пишутся?  
2. Метрики собираются?  
3. Tracing работает?  
4. Alerts корректны?  
5. UI отображает всё?  
6. Safety реагирует?  
7. Узлы и зоны мониторятся?  
8. Нет лишних алертов?  
9. Нет пропавших данных?  

---

# Конец файла LOGGING_AND_MONITORING_V4.md
