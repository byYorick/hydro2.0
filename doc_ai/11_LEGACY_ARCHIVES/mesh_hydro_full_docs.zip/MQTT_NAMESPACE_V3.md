# MQTT_NAMESPACE_V3.md
# Полный справочник MQTT‑топиков для гидропонной системы V3
# ESP32 • Python Router • Laravel Backend • Zones • Nodes • Channels

Документ описывает всю структуру MQTT-протокола, принятую в системе V3.  
Это **единый стандарт обмена данными** между:
- узлами ESP32,
- Python Scheduler,
- Laravel backend,
- UI,
- AI‑движком.

---

# 1. Общая концепция MQTT Namespace

Все топики построены строго по схеме:

```
hydro/{gh}/{zone}/{node}/{channel}/{type}
```

Где:

| Поле | Значение |
|------|----------|
| gh | Идентификатор теплицы |
| zone | ID зоны |
| node | ID узла |
| channel | канал (sensor/actuator) |
| type | telemetry / command / status / response / ota / config |

---

# 2. Структура топиков

## 2.1. Telemetry

Отправляет узел → принимает Python

```
hydro/{gh}/{zone}/{node}/{channel}/telemetry
```

Пример:

```json
{
  "value": 23.4,
  "metric": "TEMP_AIR",
  "ts": 1737355112000
}
```

---

## 2.2. Commands

Python → узел

```
hydro/{gh}/{zone}/{node}/{channel}/command
```

Пример команды:

```json
{
  "cmd": "dose",
  "params": { "ml": 1.2 },
  "cmd_id": "abc123",
  "ts": 1737355000,
  "sig": "hmac..."
}
```

---

## 2.3. Command Responses

Узел → Python → Laravel

```
hydro/{gh}/{zone}/{node}/{channel}/command_response
```

Payload:

```json
{
  "cmd_id": "abc123",
  "status": "ok",
  "details": {...},
  "ts": 1737355050
}
```

---

## 2.4. Node Status

Узел → Python → Laravel

```
hydro/{gh}/{zone}/{node}/status
```

Пример:

```json
{
  "uptime": 55331,
  "heap": 182000,
  "rssi": -63,
  "fw": "1.0.4"
}
```

---

## 2.5. OTA

Laravel/Python → Узел

```
hydro/{gh}/{zone}/{node}/ota
```

Команда OTA:

```json
{
  "version": "1.0.6",
  "url": "https://server/fw.bin",
  "sha256": "...",
  "sig": "hmac..."
}
```

Узел → ответ:

```
hydro/{gh}/{zone}/{node}/ota_report
```

---

## 2.6. Config

Laravel → Узел

```
hydro/{gh}/{zone}/{node}/config
```

Payload:

```json
{
  "channels": [...],
  "calibration": {...},
  "wifi": {...}
}
```

---

# 3. Структура top‑level namespace

```
hydro/
   gh1/
      zone1/
         node4/
            PH_SENSOR/
            EC_SENSOR/
            TEMP_AIR/
            IRRIGATION_PUMP/
            ...
```

---

# 4. Каналы (channel)

Каждый канал — это один сенсор или актуатор.

Типы:

### Сенсоры:
- PH
- EC
- TEMP_AIR
- HUMIDITY
- TEMP_WATER
- WATER_LEVEL
- FLOW
- LIGHT

### Актуаторы:
- DOSE_ACID
- DOSE_BASE
- DOSE_NUTRIENT
- IRRIGATION_PUMP
- FAN
- HEATER
- LIGHT_RELAY
- VALVE

---

# 5. Правила для сообщений telemetry

## 5.1. Обязательные поля:

```
value
ts
```

## 5.2. Опциональные:

```
temperature
quality
unit
```

## 5.3. Нельзя:

- отправлять telemetry быстрее чем 200–500 мс
- превышать размер JSON > 1 KB

---

# 6. Правила для сообщений command

Команда должна содержать:

```
cmd
params
cmd_id
ts
sig
```

Подпись `sig` = HMAC SHA256 по:

```
{cmd}|{ts}|node_secret
```

---

# 7. Правила для command_response

Статус:

- ok
- error
- timeout
- busy

---

# 8. Тематические пространства MQTT

## 8.1. Для Telemetry

```
hydro/+/+/+/+/telemetry
```

Python подписывается.

---

## 8.2. Для Commands

```
hydro/gh/zone/node/channel/command
```

Узел подписывается строго на свой top‑level.

---

## 8.3. Для OTA

Узел подписывается на:

```
hydro/{gh}/{zone}/{node}/ota
```

---

## 8.4. Для Status

Узел публикует:

```
hydro/{gh}/{zone}/{node}/status
```

---

# 9. ACL правила для MQTT

ACL файл:

```
user python
topic readwrite hydro/#

user esp32
topic read hydro/+/+/+/+/command
topic read hydro/+/+/+/+/config
topic read hydro/+/+/+/ota
topic write hydro/+/+/+/+/telemetry
topic write hydro/+/+/+/status
topic write hydro/+/+/+/+/command_response
topic write hydro/+/+/+/ota_report
```

---

# 10. Интеграция с Python Scheduler

Scheduler слушает:

- `telemetry`
- `command_response`
- `status`

Scheduler отправляет:

- `command`
- `config`

---

# 11. Интеграция с Laravel

Laravel слушает:

- status (через websockets/event forwarding)
- command_response
- ota_report

Laravel отправляет:

- config
- ota

---

# 12. Интеграция с AI-сервисом

AI получает:

- telemetry (через REST)
- commands history
- alerts history

AI НЕ общается напрямую с MQTT.

---

# 13. Правила для ИИ

ИИ может:

- расширять namespace,
- добавлять новые каналы,
- вводить новые команды,
- оптимизировать структуру payload.

ИИ НЕ может:

- менять существующие топики,
- изменять имена каналов,
- убирать ts или value,
- отключать подписи команд.

---

# 14. Чек‑лист MQTT перед релизом

1. Все узлы имеют уникальный namespace?  
2. Команды подписаны?  
3. OTA работает?  
4. telemetry корректная?  
5. command_response приходит вовремя?  
6. ACL настроен?  
7. Python получает всё?  
8. Laravel получает всё?  

---

# Конец файла MQTT_NAMESPACE_V3.md
